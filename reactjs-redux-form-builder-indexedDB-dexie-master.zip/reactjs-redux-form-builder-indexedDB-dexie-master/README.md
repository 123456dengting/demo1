# Form Builder React JS + Redux + Dexie Indexed DB
Hello Reacter
Just show source code from my last project, create form builder under React JS + Redux thunk with service worker enabled, offline databse enabled with Indexed DB ( one of Browser API ) part of Progressive Web App


## Demo

Look up demo on https://react-form-builder-pwa.netlify.com

![Image of Screenshot](https://github.com/agilworld/reactjs-redux-form-builder-indexedDB-dexie/raw/master/screenshot.png)

## Clone & Install

clone this repo from your favourite terminal or VSC then type `npm install`. run this code by `yarn start` or `npm run start`. Build this code by `yarn build` or `npm run build`

## Contributor :
agil.rahadi@gmail.com a.k.a https://linkedin.com/in/dianafrial

Let me know if any bug issue or request pull requesst

Thanks

In Collaboration with http://batamjs.org

## Credits :

- Bootstrap latest version
- Dexie
- Font awesome
