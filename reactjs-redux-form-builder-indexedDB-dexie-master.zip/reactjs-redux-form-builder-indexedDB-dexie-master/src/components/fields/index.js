import Text from './Text'
import Textarea from './Textarea'

export { Text, Textarea }