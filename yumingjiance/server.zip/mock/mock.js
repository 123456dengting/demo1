const { moment } = require('../utils/utils');
function tempTime(i) {
    return moment('h:m:s', parseInt(new Date().getTime()) + (i) * 1000);
}

function tempId(i) {
    return `${i}`;
}

const data = [
    { "id": tempId(2), "keyword": "rosegal", "domainSign": "rosegal","execTime": [{ "id": "65", "time": tempTime(2), "keywordId": tempId(2) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(2) }], "devices":[{"userAgent": "PC"}] },
    // { "id": tempId(1), "keyword": "rosegal", "domainSign": "rosegal", "execTime": [{ "id": "65", "time": tempTime(1), "keywordId": tempId(1) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(1) }, { "id": "67", "name": "澳大利亚", "keyWordId": tempId(1) }, { "id": "67", "name": "法国", "keyWordId": tempId(1) }, { "id": "67", "name": "英国", "keyWordId": tempId(1) }, { "id": "67", "name": "加拿大", "keyWordId": tempId(1) }] },
    // { "id": tempId(3), "keyword": "rosegal", "domainSign": "rosegal","execTime": [{ "id": "65", "time": tempTime(3), "keywordId": tempId(3) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(3) }, { "id": "67", "name": "澳大利亚", "keyWordId": tempId(3) }] },
    // { "id": tempId(4), "keyword": "rosegal", "domainSign": "rosegal","execTime": [{ "id": "65", "time": tempTime(4), "keywordId": tempId(4) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(4) }, { "id": "67", "name": "法国", "keyWordId": tempId(4) }] },
    // { "id": tempId(5), "keyword": "rosegal", "domainSign": "rosegal","execTime": [{ "id": "65", "time": tempTime(20), "keywordId": tempId(5) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(5) }, { "id": "67", "name": "加拿大", "keyWordId": tempId(5) }] },
    // { "id": tempId(6), "keyword": "rosegal", "domainSign": "rosegal","execTime": [{ "id": "65", "time": tempTime(30), "keywordId": tempId(6) }], "country": [{ "id": "66", "name": "美国", "keyWordId": tempId(6) }] }
];

module.exports = data