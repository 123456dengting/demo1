var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var api = require('./routes/api');
var cors = require('./middleware/cors');
var app = express();
//socket.io
var io = require('socket.io')(svr);
var fs = require('fs');

const config = require('./config');     //基础配置参数
const PATH = path.resolve(__dirname, config['DATA_PATH']);
const { TIMEOUT_RUN, HEADLESS, UA, GOOGLE_URLS } = config;

const puppeteer = require('puppeteer');
const { timeout, readFilePromise, writeFilePromise, isObjectValueEqual, paramsStringToJson, kvArrayToObject, getMsgObject, moment, trim, isElementsInArray, guid, mkdirs } = require('./utils/utils');
const TIMEOUT = 120000;
var URL = require('url');

app.use(cors);    //跨域问题
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
// app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'ars')));

app.use('/api', api);


var server = app.listen('3007', function () {
    console.info('Express server listening on port ' + server.address().port);
})

module.exports = app;