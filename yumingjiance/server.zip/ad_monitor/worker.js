const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, HEADLESS, TYPE_2_USERAGENT, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS, COUNTRY_TO_GURL } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, moment, guid } = require('../utils/utils');
const devices = require('puppeteer/DeviceDescriptors');
const SELECTOR = {
    'PC': {
        adBlock: '.ads-ad',
        adTitle: '.ad_cclk',
        adBody: '.ellip',
        adUrl: '.ad_cclk h3 a:not([style*="display:none"])',
        nextPage: '.b.navend:last-child a',
        setLanguages: '#lb > div > a:nth-child(2)'

    },
    'iPad': {
        adBlock: '.ads-fr',
        adTitle: 'a[data-rw] div[aria-level]',
        adBody: '[data-hveid] > [data-rid] > div:nth-child(3) > div:first-child',
        adUrl: 'a[data-rw] div:last-child span:last-child',
        nextPage: '#botstuff > div > div:nth-child(4) > h3:nth-child(4) > a > div > span:last-child'

    },
    'mobile': {
        adBlock: '.ads-fr',
        adTitle: 'a[data-rw] div[aria-level]',
        adBody: '[data-hveid] > [data-rid] > div:nth-child(3) > div:first-child',
        adUrl: 'a[data-rw] div:last-child span:last-child',
        nextPage: '#botstuff > div > div:nth-child(4) > h3:nth-child(4) > a > div > span:last-child'
    },
};
const languages = [
    {
        "label": "English",
        "value": "en"
    },
    {
        "label": "Deutsch",
        "value": "de"
    },
    {
        "label": "español",
        "value": "es"
    },
    {
        "label": "français",
        "value": "fr"
    },
    {
        "label": "italiano",
        "value": "it"
    },
    {
        "label": "português (Portugal)",
        "value": "pt-PT"
    }
]
const setLanguages = {
    'PC': {
        adBlock: '.ads-ad',
        adTitle: '.ad_cclk',
        adBody: '.ellip',
        adUrl: '.ad_cclk h3 a:not([style*="display:none"])',
        nextPage: '.b.navend:last-child a'

    },
    'iPad': {
        adBlock: '.ads-fr',
        adTitle: 'a[data-rw] div[aria-level]',
        adBody: '[data-hveid] > [data-rid] > div:nth-child(3) > div:first-child',
        adUrl: 'a[data-rw] div:last-child span:last-child',
        nextPage: '#botstuff > div > div:nth-child(4) > h3:nth-child(4) > a > div > span:last-child'

    },
    'mobile': {
        adBlock: '.ads-fr',
        adTitle: 'a[data-rw] div[aria-level]',
        adBody: '[data-hveid] > [data-rid] > div:nth-child(3) > div:first-child',
        adUrl: 'a[data-rw] div:last-child span:last-child',
        nextPage: '#botstuff > div > div:nth-child(4) > h3:nth-child(4) > a > div > span:last-child'
    },
}
const logger = require('../common/log');     // 日志模块


class Worker {
    constructor() {
        this.runResolve = null;
        this.runReject = null;
        this.domainSign = 'rosegal';      // 网站标识名
        this.signToJump = false;    // 记录跳转标识       
        this.redirections = [];    // 记录跳转url
        this.guid = guid(true); // get short guid
    }

    async getAdText(page) {
        return await page.evaluate(opts => {
            const [ domainSign, userAgent, SELECTOR ] = opts;
            let eAds = document.querySelectorAll(SELECTOR[userAgent].adBlock);
            let adTitle = [], adBody = [], adLink = [];
            for (var i = 0, len = eAds.length; i < len; i++) {
                var it = eAds[i];
                var eAdTitle = it.querySelector(SELECTOR[userAgent].adTitle).innerText;
                if (eAdTitle.toLowerCase().indexOf(domainSign) > -1) {
                    var eAdBody = it.querySelectorAll(SELECTOR[userAgent].adBody);
                    adTitle.push(eAdTitle);
                    adBody.push(Array.from(eAdBody).reduce((a, b) => a += b.innerText, ''));
                }
            }
            return { title: adTitle, body: adBody };
        }, [this.domainSign, this.param.userAgent, SELECTOR]);
    }

    async secureClick(el, page) {
        const Mouse = page.mouse;
        await el.hover();
        const { x, y } = await el.boundingBox();
        await Mouse.move(x, y);
        await timeout(Math.random() * 300);
        await Mouse.click(x, y);
    }

    async getAdUrl(page, reject) {
        const { userAgent } = this.param;
        const eAds = await page.$$(SELECTOR[userAgent].adBlock);
        let urls = [];

        for (let i = 0; i < eAds.length; i++) {
            await timeout(Math.random() * 500 + 3500);            
            const eAds = await page.$$(SELECTOR[userAgent].adBlock);
            const urlText = eAds.length - 1 < i ? '' : await page.evaluate(el => el.innerText, await eAds[i].$(SELECTOR[userAgent].adTitle));

            if (urlText.toLowerCase().indexOf(this.domainSign) > -1) {
                const el = await eAds[i].$(SELECTOR[userAgent].adUrl);
                const nowUrl = await page.url();
                await timeout(Math.random() * 1000);
                this.setRedirectsState(true); 
                await this.secureClick(el, page);
                await page.waitForNavigation({ timeout: 0 });
                await timeout(Math.random() * 500 + 200);
                let waitSumTime = 0;
                while (this.signToJump && waitSumTime < 10000) {
                    await timeout(50);
                    waitSumTime += 50;
                }
                const urlParam = this.redirections.length > 0 ? this.redirections.splice(-1, 1)[0] : { url: '', params: '' };
                const timeStamp = new Date().getTime();
                const redirections = this.redirections;
                const execTime = moment('Y-M-D h:m:s', timeStamp);
                logger.trace(`[${this.guid}]`, `Jumping to target spend time(ms) ${waitSumTime} :`);
                urls.push({ timeStamp, execTime, ...urlParam, redirections });
                // console.log(urls, 'urls')
                this.redirections = [];
                try {
                    await page.goto(nowUrl, LOADOPTS);
                    if (await this.isBlockedByGoogle(page)) {
                        logger.warn(`[${this.guid}]`, `Url: ${nowUrl} Blocked by google ...`);                       
                        reject(-1);
                        return;
                    }
                } catch (err) {
                    logger.error(`[${this.guid}]`, `Catching error of goto ${googleUrl} network err ... `);
                    return false;
                }
            }
            await timeout(200);
        }
        return urls
    }

    setRedirectsState(isStart) {
        if(isStart) {
            this.signToJump = true;
            this.reqUrls = [];
            this.resUrls = [];
        } else {
            this.signToJump = false;
        }
    }

    async isBlockedByGoogle(page) {
        const pageUrl = await page.url();
        return pageUrl.startsWith('https://ipv4.google.com');
    }

    getUserAgent(UAType) {
        switch (UAType) {
            case 'iPad':
                return devices['iPad'].userAgent;
                break;
            case 'mobile': 
                return devices['iPhone 6'].userAgent;
                break;
            default:
                return TYPE_2_USERAGENT['PC'];
                break;
        }
    }
    handleResponse(res) {
        if(this.signToJump){     
            this.resUrls.push(res.url);   
            // res.ok status 200-299
            logger.trace(`[${this.guid}]`, `Response url:${res.url}, status: ${res.status}`);
            if ((res.ok || res.status === 304 ) && res.url.split('?')[0].indexOf(this.domainSign) !== -1 ) {
                this.signToJump = false;     //获取到重定向终点之后改变标识
            }
        }
    }

    async handleRequest(req) {
        if (this.signToJump && req.resourceType === "document") {
            let arrStr = req.url.split('?');
            this.reqUrls.push(req.url);
            logger.trace(`[${this.guid}]`, `Request url: ${req.url} ...`);
            arrStr.splice(0, 1);
            this.redirections.push({ url: req.url, params: paramsStringToJson(arrStr.join("")) });
        }
    }
    async run(param, page) {
        this.param = param;
        this.domainSign = param.domainSign ? param.domainSign.toLowerCase() : this.domainSign;
        const startTime = new Date().getTime();
        return new Promise(async (resolve, reject) => {
            const { userAgent } = param;
            logger.trace(`[${this.guid}]`, 'Worker is starting ...', `${param.id}-${param.keyword}-${param.userAgent}-${param.country}`);
            const timer = setTimeout(() => { reject(-1); return false;}, 240000);// 超时
            await page.setUserAgent(this.getUserAgent(param.userAgent)); // 设置ua
            page.on('request', this.handleRequest.bind(this));
            page.on('response', this.handleResponse.bind(this));

            const googleUrl = COUNTRY_TO_GURL[param.country] + '/search?hl=en&q=' + param.keyword;
            try {
                await page.goto(googleUrl, LOADOPTS);
                if(await this.isBlockedByGoogle(page)) {
                    logger.warn(`[${this.guid}]`, `Url: ${nowUrl} Blocked by google ...`);          
                    reject(-1);
                    return ;
                }
            } catch (e) {
                logger.error(`[${this.guid}]`, `Catching error of goto ${googleUrl} network err ... `);
                reject(-1);
                return ;
            }


            await timeout(Math.random() * 200 + 1000);
            const pageUrl = await page.url();
            let info = [];
            
            for (let i = 0; i < 5; i++) {
                await timeout(Math.random() * 500 + 500);
                if(i > 0){
                    try {
                        await page.click(SELECTOR[userAgent].nextPage);                      
                        logger.trace(`[${this.guid}]`, `Jumping Page <${i + 1}> ...`)
                    } catch (err) {
                        logger.warn(`[${this.guid}]`, 'The search has pages less than 5...');
                        resolve({ key: param.keyword, data: info });                        
                    }
                    // await page.waitForNavigation(LOADOPTS);  // wait next page loaded   
                }
                await timeout(Math.random() * 500 + 2500);
                const adText = await this.getAdText(page);
                logger.info(`[${this.guid}]`, 'Adding text:', adText);
                const adUrl = await this.getAdUrl(page, reject);
                if(!adUrl) { reject(-1); return ;}
                adUrl.forEach((it, j) => {
                    const domain = it.url.trim() ? it.url.split('/')[0] + '//' + it.url.split('/')[2] : "";
                    const lkid = it.params.lkid ? it.params.lkid : '';
                    const title = adText.title[j];
                    const body = adText.body[j];
                    const fromPage = i + 1;       // 搜索页码
                    const country = param.country;    // 当前检测的国家
                    info.push({ domain, title, body, country, lkid, fromPage, ...it });
                })
            }
            if (await this.isBlockedByGoogle(page)) {
                reject(-1);
                return;
            }
            resolve({ key: param.keyword, data: info });
            clearTimeout(timer);
            logger.trace(`[${this.guid}]`, 'This task spend times: ', new Date().getTime() - startTime);
        })
    }

}

module.exports = Worker;