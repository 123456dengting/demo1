var path = require('path');
const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, UA, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, moment } = require('../utils/utils');
const puppeteer = require('puppeteer');
const TIMEOUT = 120000;

const Worker = require('./worker');  // 广告爬取任务模块
const Ajax = require('../common/ajax');  // 数据交互模块
const logger = require('../common/log');     // 日志模块
const Notification = require('../common/notification');

const HEADLESS = false;
const BROWSER_COUNT = 4;    // browser实例最大数
const MAX_PAGES = 1;        // 每个browser实例最多启动页数
const MAX_RUN_TIMES = 0;    // browser run times
const MAX_RUNNING_BROWSER = 1;
const TEST_BROSER_URL = GOOGLE_URLS[0] + '/search?hl=en&q=rosegal';

class Dispatcher {
	constructor() {
		this.browsers = [];
		this.waitForStore = [];
		this.queueStore = [];
		this.initBrowsersState = false;
		this.createBrowsers();
		this.sleepTime = 0;
	}
	
	async createBrowser() {
		try{
			let browser = await puppeteer.launch({
				headless: false,
				// args: ['--proxy-server=' + await getPublicIp()]
			});
			return browser;
		}catch(e) {
			console.error(e)
		}
		
	}

	async createBrowsers() {
		let prBrowsers = [];
		for (let i = 0; i < BROWSER_COUNT; i++) {
			prBrowsers.push(this.createBrowser());
		}
		
		try {
			const res = await Promise.all(prBrowsers);

			this.browsers = await res.map(async it => ({ status: -1, runTimes: 0, browser: it, pages: await this.createPages(it) }))
			this.browsers = await Promise.all(this.browsers);
			this.initBrowsersState = true;
		} catch (err) {
			logger.error('created Browsers err');
		}
	}
	
	async createPage(browser) {
		return await browser.newPage();
	}

	async createPages(browser){
		let pages = [];
		let prPages = [];
		for (let i = 0; i < MAX_PAGES; i++) {
			prPages = [...prPages, this.createPage(browser)];
		}
		try {
			const res = await Promise.all(prPages);
			return res.map(it => ({status: -1, page: it}));
		} catch (err) {
			console.error(err);
		}
	}

	async isBlockedByGoogle(page) {
		const pageUrl = await page.url();
		return pageUrl.startsWith('https://ipv4.google.com')
	}

	async isBrowserCanRun(page) {
		try {
			await page.goto(TEST_BROSER_URL, LOADOPTS);			
			const isBlocked = await this.isBlockedByGoogle(page);
			if( !isBlocked ) await page.close();
			return !isBlocked;
		} catch (err) {
			return false;
		}
	}

	busyBrowserCount() {
		return this.browsers.reduce((a, it) => { const b = it.status === 1 ? 1 : 0; return a + b; }, 0);
	}

	async handlePuppeteerCore() {
		while(!this.initBrowsersState)  await timeout(500);
		const { browsers } = this;
		let page;
		let hasFree = false;
		if (this.busyBrowserCount() > MAX_RUNNING_BROWSER) return false;

		this.browsers = browsers.map((it, i) => {
			if (!hasFree && 'pages' in it && it.status === -1 && it.runTimes <= MAX_RUN_TIMES) {
				hasFree = it.pages.some((it2, j) => {
					if(it2.status === -1) {
						page = { page: it2.page, index: [i, j] };
						it.pages[j].status = 1;
						it.runTimes++;
						return true;
					}
				});
				// 不存在正在执行的page，此browser空闲
				if(hasFree) it.status = 1;      
			}
			return it;
		});
		return page;
	}

	isThisBrowserFree(i) {
		const browser = this.browsers[i];
		const isHasBusy = it => it.status === 1;
		return !browser.pages.some(isHasBusy);
	}

	async run(data, isFirstRun = true) {		
		logger.trace('load task:', data);
		const page = await this.handlePuppeteerCore();
		await timeout(Math.random() * 2000 + 4000);		
		if(!page) {
			logger.info('Page is busy...', `browsers count is: ${this.browsers.length}`);
			this.waitForBrowserFree(data);
		}else {
			const timer = setTimeout(() => {
				logger.warn('Dispatch timeout...');
				this.waitForBrowserFree(data);					
				this.resetStateAfterRun(page.index);
			}, 300000);	
			try {	
				// 检测全局休眠时间并执行休眠	
				if(this.sleepTime > 0) {
					await timeout(this.sleepTime);
					this.sleepTime = 0;
				}
				if(isFirstRun) this.setQueueStore({ data: data, status: -2, startTime: new Date().getTime(), coreIndex: page.index });
				const res = await new Worker().run(data, page.page);
				logger.trace("Worker promise resolve", res);				
				clearTimeout(timer);
				logger.trace("clearTimeout timer...");
				this.resetStateAfterRun(page.index);
				const resData = this.exChangeReturnData(res, data);
				// TODO 暂停提交数据
				// await Ajax.handlePostResult(resData);    // 提交结果数据
				logger.trace('Post data success...')
			} catch (err) {
				logger.error('Worker rejected ...', err);
				clearTimeout(timer);		
				logger.trace("clearTimeout timer...");						
				const [i, j] = page.index;				
				if(err === -1) {
					await this.changeProxy(page.index);
					await timeout(Math.random() * 500 + 3000);
					// 取出当前browser重启前运行中的页面, 返回运行的Promise数组
					const pmAdSpiderRun = await this.queueStore.filter(it => it.coreIndex[0] === i && it.status === -2).map(async (it2, k) => await this.run(it2.data, false));					
					await Promise.all(pmAdSpiderRun);
				}
			}
		}
	}

	resetStateAfterRun(index) {
		this.removeQueueStore(index);
		this.handleBrowserState(index);
		this.dispatchWaitForRunData();  // 运行等待队列中
	}

	handleBrowserState([i, j]){
		const browser = this.browsers[i];
		browser.pages[j].status = -1;
		if (this.isThisBrowserFree(i)) browser.status = -1;
		if (browser.runTimes > MAX_RUN_TIMES && browser.status === -1) this.changeProxy([i]);		
	}

	setQueueStore(el) {
		const { queueStore } = this;		
		this.queueStore = [...queueStore, el];
	}

	removeQueueStore(index) {
		const { queueStore } = this;
		this.queueStore = queueStore.filter(it => it.coreIndex.toString() !== index.toString());
	}

	async changeProxy([i]) {
		logger.info(`Browser <${i}> restaring ...`);
		const { browsers } = this;
		const { pages } = browsers[i];
		// const pmPages = pages.map(it => it.page.close());
		try {
			// await Promise.all(pmPages);
			await this.browsers[i].browser.close();
			await timeout(1500);
		} catch (err) {
			logger.error(`Browser <${i}> close failed ...`);
		}
		this.browsers[i].browser = await this.createBrowser();
		this.browsers[i].pages = await this.createPages(this.browsers[i].browser);
		this.browsers[i].status = -1;
		this.browsers[i].runTimes = 0;
		logger.info(`Browser <${i}> restart success ...`);
	}

	waitForBrowserFree(data) {
		const { waitForStore } = this;
		this.waitForStore = [...waitForStore, data];
	}
	/**
	 * 判断与当前时间对比是否超时
	 * @param {string} timeOri 初始时间
	 * @param {number=} [timeoutCount=1800000] 时间差，默认30分钟
	 * @returns {boolean} 是否超时
	 * @memberof Dispatcher
	 */
	isTimeout(timeOri, timeoutCount = 5400000 ) {
		return new Date().getTime() - new Date(timeOri).getTime() > timeoutCount;
	}

	dispatchWaitForRunData(){
		const { waitForStore } = this;
		const waitLen = waitForStore.length;
		logger.trace('Dispatching wait-task ...', waitLen);
		waitForStore.forEach((it, i) => { 
			this.waitForStore.splice(i, 1); 
			if (!this.isTimeout(it.originTime))         // 是否超时运行时间
				this.run(it);
			else {
				Notification.entry(it);				
				logger.trace('The task is timeout: ', it);
			}
		});
	}

	exChangeReturnData(res, param) {
		const resData = res.data.map(it => ({
			keyword: res.key,
			domainSign: param.domainSign,
			advertisingWord: it.title,
			advertisingContent: it.body,
			requestUrl: it.url,
			source: "来源---",
			account: "账号---",
			email: "email---",
			execTime: it.execTime,
			country: it.country,
			redirections: it.redirections.map(_it => ({ url: _it.url })),
			userAgent: param.userAgent,
			lkid: it.lkid,
			fromPage: it.fromPage
		}));
		const { id } = param;
		return {resData, id};
	}


}


const _Spider = new Dispatcher();

module.exports = _Spider;
