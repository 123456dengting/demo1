const Ajax = require('../common/ajax');
const qs = require('querystring');
/**
 * @const
 * 通道标识数组转换
 */
const SIGN2SIGN = {
    email: 'yxhf',
    wechat: 'weixin',
    rtx: 'rtx'
}; 
const NOTIFICATION_TITLE = 'ARS自动化测试结果';
const AD_RESULT_URL = 'http://10.28.1.81:3001/ad-monitor/result';
/**
 * @file 通知推送模块
 * @author (xiezicong@globalegrow.com)
 * @class Notification
 */
class Notification {
    /**
     * Creates an instance of Notification.
     * @memberof Notification
     */
    constructor() {
        this.initData();
        // 载入订阅信息列表
        this.loadSubscriptions();
    }
    /**
     * 初始化数据
     * @memberof Notification
     */
    initData() {
        this.subscriptions = false;
        this.type = 'ad';
    }
    /**
     * 判断订阅数据是否装载
     * @returns {boolean} 是否装载
     * @memberof Notification
     */
    isLoadSubscriptions() {
        return this.subscriptions;
    }
    /**
     * 处理订阅数组
     * @param {Array} res 
     * @returns {Array} 返回处理后数组 
     * @memberof Notification
     */
    handleSubscriptions(res) {
        return res.reduce((pre, current) => {
            const keyword = current.keyword ? current.keyword : [];
            const website = current.website ? current.website : [];
            const type = JSON.parse(current.push_type);
            const push_person = JSON.parse(current.push_person);
            const arr = type.map(push_type => ({...current, push_person, push_type, keyword, website}));
            return [ ...pre, ...arr ]
        }, []);
    }
    /**
     * 异步获取订阅数据
     * @memberof Notification
     */
    async loadSubscriptions() {
        const res = await Ajax.getSubscriptions();
        this.subscriptions = res ? this.handleSubscriptions(res) : [];
    }
    /**
     * 异步发送通知
     * @param {any} subscriptions 
     * @memberof Notification
     */
    async sendNotification(subscriptions, param) {
        const postData = Object.values(this.handlePostData(subscriptions, param));
        if(this.isHasTargetToSend(postData)) await Ajax.postNotification(postData);
    }
    /**
     * 判断通道是否存在目标
     * @param {Array} channels 
     * @returns {boolean} 是/否
     * @memberof Notification
     */
    isHasTargetToSend(channels) {
        const isToHasValue = it => it.to.trim().length > 0;
        return channels.some(isToHasValue);
    }
    /**
     * 创建通知内容
     * @returns {string} 通知内容 
     * @memberof Notification
     */
    createAdNotificationContent(param) {
        if (this.type === 'ad') {
            const projName = 'Google关键字'; 
            const {keyword, country, userAgent, originTime} = param;
            return `项目名称: ${projName}\n运行时间: ${originTime}\n运行结果: {${keyword}-${country}-${userAgent}}  未运行\n`;
        }else{
            const projName = 'JS监测';
            const {name, originTime, url} = param;
            return `项目名称: ${projName}\n运行时间: ${originTime}\n运行结果: {${name}-<${url}>} 未执行\n异常原因: 执行时间超时`;
        }
    }
    /**
     * 处理发送前数据
     * @param {Array} subscriptions 订阅数组 
     * @returns {Array} 通知数组
     * @memberof Notification
     */
    handlePostData(subscriptions, param) {
        const channels = {};
        const title = NOTIFICATION_TITLE;
        const content = this.createAdNotificationContent(param);
        Object.values(SIGN2SIGN).map(it => channels[it] = { channel: it, to: '', content, title });
        subscriptions.forEach(it => {
            const pushType = SIGN2SIGN[it.push_type];
            channels[pushType].to = this.handleStringOfTo(it.push_type ,channels[pushType].to, it.push_person);
        });
        return channels;
    }
    /**
     * 根据通道关键字返回目标字符串
     * @param {string} channel 通道关键字 
     * @param {string} str 目标拼接字符串
     * @param {Object} person 当前目标对象 
     * @returns {string} 目标拼接字符串
     * @memberof Notification
     */
    handleStringOfTo(channel, str, person) {
        switch (channel) {
            case 'rtx':
                str += `${person.unique_id},`;
                break;
            case 'wechat':
                str += `${person.name},`;
                break;
            case 'email':
                str += `${person.name}@globalegrow.com,`;
                break;
            default:
                break;
        }
        return str;
    }
    /**
     * 入口方法
     * @public
     * @param {Object} param 运行配置对象 
     * @param {string=} [type='ad'] 通知源头类型 
     * @memberof Notification
     */
    entry(param, type = 'ad') {
        console.log('Notification entry-----');
        this.type = type;
        if(this.isLoadSubscriptions) {
            const { keyword, name } = param;
            const sign = type === 'ad' ? keyword : name;
            const isInArray = it => it.name === sign;
            const isType = type === 'ad' ? it => it.keyword.some(isInArray) : it => it.website.some(isInArray);
            const subscriptions = this.subscriptions.filter(isType);
            console.log(subscriptions, 'subscriptions--------');
            if (subscriptions.length > 0) this.sendNotification(subscriptions, param);
        }
    }
    /**
     * 创建访问链接
     * @param {object} res 测试结果
     * @param {object} { keyword } 测试配置
     * @returns { search }
     * @memberof Notification
     */
    createViewResultUrl(res, { keyword }) {
        const start = this.getTimeStamp(res.resData[0].execTime);
        const end = this.getTimeStamp(res.resData.slice(-1)[0].execTime);
        return AD_RESULT_URL + qs.stringify({ keyword, start, end });
    }

    /**
     * 获取时间戳
     * @param {?Date} time 时间对象
     * @returns {string} 时间戳
     * @memberof Notification
     */
    getTimeStamp(time) {
        return time ? new Date(time).getTime() : new Date().getTime();
    }

}

module.exports = new Notification();