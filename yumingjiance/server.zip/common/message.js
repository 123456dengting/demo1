const { isObject } = require('../utils/utils');

class Message {
    constructor(_className) {
        this.className = _className;
    }

    error(msg, fn) {
        fn = fn ? `in ${fn}` : '';
        console.error(`^_^ |  [error] error occurred at @${this.className} ${fn} <: ${msg} > |`);
    }

    info(...all) {
        all.forEach(it => {
            const type =  typeof it;
            switch (true) {
                case typeof it === "string":
                    if(it.length === 0) it = `{this is an undefined variable}`;
                    console.log(`=*= | [info] <${type}> @${this.className} ${it}`)
                    break;
                case isObject(it):
                case Array.isArray(it):
                    console.log(`=*= | [info] <${type}> @${this.className} --------------- begin ------------`);
                    console.log(it);
                    console.log(`=*= | [info] <${type}> @${this.className} --------------- end ------------`);
                    break;
                default:
                    console.log(`=*= | [info] <${type}> @${this.className} ${it}`);
                    break;
            }
        });
    }
}

module.exports = Message;