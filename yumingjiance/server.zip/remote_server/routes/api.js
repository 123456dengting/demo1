const router = require('express').Router();
const path = require('path');
const entry = require('../ad_monitor/entry');
router.get('/send/task', async (req, res, next) => {
    const params = req.query;
    const retData = await entry.apiEntry(params, 'dispatchTask');
    res.send(retData);
})

module.exports = router;