const path = require('path');
const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, HEADLESS, UA, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, moment, isObject, deepObj2array } = require('../utils/utils');
const rp = require('request-promise');   // request 支持promise版本
const Message = require('./Message');
class Ajax extends Message {
    constructor(){
        super('Ajax');
    }

    /**
     * handlePostResult
     * 处理并发提交过程
     * @param { object } res  
     * @memberof Ajax
     */
    async handlePostResult(res) {
        console.log('res:', res);
        res = this.handleResData(res);     
        if (res.length > 0) {
            // 如果返回的是Promise.all返回的数组res
            const postData = res.reduce((a, b) => a.concat(b.resData), []);
            const resData = await this.postResults(postData);
        }
    }

    /**
     * handleResData
     * 递归处理提交数据，使数据扁平
     * @param { object } res 需要提交的数据 
     * @returns { array } 返回扁平数组
     * @memberof Ajax
     */
    handleResData(res) {
        res = !Array.isArray(res) ? [res] : res;
        const retData = [];
        res.forEach(it => {
            if (isObject(it) && it.resData) {
                retData.push(it);
            } else if (Array.isArray(it)) {
                retData.concat(this.handleResData(it));
            }
        })
        return retData;
    }
    /**
     * postResult
     * 提交数据
     * @param { object } param 数据块参数 
     * @return { promise } 
     * @memberof Ajax 
     */
    async postResult(param) {
        const postData = JSON.stringify({ "actionid": "10", "autoTestResult": param });
        try {
            let res = await rp.post({ url: config.url + ':' + config.port + '/api/AutoTestResult', form: { json: postData } });
            res = JSON.parse(res);
            if (res.code !== 1) {
                res.data = JSON.parse(res.data);
                throw res.data.msg;
            } else {
                console.log('postResult success--------')
            }
        } catch (err) {
            console.error(err);
        }
    }

    /**
     * postResults
     * 并行提交批量数据
     * @param { array } params 数组形式数据参数 
     * @returns { promise } 异步
     * @memberof Ajax
     */
    async postResults(params) {
        const pmPostResults = params.map(it => this.postResult(it));
        try {
            await Promise.all(pmPostResults);
            return true;
            console.log(`keyword: ${it.keyword}, id: ${it.id} run at ${it.execTime} post success..`);
        } catch (err) {
            console.error(err);
        }
    }

    /**
     * getParams
     * 获取初始化配置参数
     * @returns { <promise> array } 数组形式配置数据
     * @memberof Ajax
     */
    async getParams() {
        const url = config.url + ':' + config.port + '/api/AutoTestGetKeyWord';
        const params = { actionid: "7", id: "-1" };
        const res = await this.post(url, params);
        if(!res || typeof res === "string" || res.code !== 1){
            return [];
        }else {
            const { keyword } = res.data.autoTest;
            return deepObj2array(keyword, 'country', 'execTime', 'devices');
        }
    }
    
    
    /**
     * @method getJSMonitorParams
     * @description 获取初始化配置参数
     * @returns { <promise> object | undefined } 数组形式配置数据
     * @memberof Ajax
     */
    async getJSMonitorParams() {
        const url = config.url + ':' + config.port + '/api/getDomain';
        const params = { actionid: 2, id: -1 };
        const res = await this.post(url, params);
        
        if (res && typeof res !== "string" && res.code === 1) {
            const website = res.data.webScriptTest.website;
            return deepObj2array(website, 'execTimes', 'pages', 'tests', 'params');
        }
    }

    /**
     * @method post
     * @description 封装post方法
     * @param { string } url  
     * @param { object } params 
     * @returns { <Promise> object | undefined } promise 返回数据
     * @memberof Ajax
     */
    async post(url, params) {
        try {
            return JSON.parse(await rp.post({ url, form: { json: JSON.stringify(params) } }));            
        } catch (err) {
            console.error(err);
        }
    }

    async postJSMonitorResult(postData) {
        const url = config.url + ':' + config.port + '/api/addDomainTestResult';
        const params = { actionid: 5, ...postData };
        const res = await this.post(url, params);
        this.info(res,'JSMonitorPost Result------');
    }





}

module.exports = new Ajax();