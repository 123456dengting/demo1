const { writeFilePromise, mkdirs, moment, readFilePromise, appendFilePromise } = require('../utils/utils');
const path = require('path');
const PATH = path.resolve(__dirname, '../logs/');

class Logs {

    static async addLogs(resData, param) {
        console.log('addLogs----------------');
        const filePath = path.resolve(PATH, 'monitor/' + moment('Y/M/D/'));
        const fileName = 'logs.json';
        resData.param = param;
        await this.saveDataAsLogFile(JSON.stringify(resData), filePath, fileName);
    }

    static async saveDataAsLogFile(logData, filePath, fileName) {
        try {
            mkdirs(filePath, async function () {
                const res = await appendFilePromise(logData, filePath + '/' + fileName);
                console.log('Save logData success----');
            })
        } catch (err) {
            console.error(err);
            console.log('Save logData Error!');
        }
    }

}



module.exports = Logs;