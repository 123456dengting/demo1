var path = require('path');
const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, UA, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, moment } = require('../utils/utils');
const puppeteer = require('puppeteer');
const TIMEOUT = 120000;

const Worker = require('./worker');  // 广告爬取任务模块
const Ajax = require('../common/ajax');  // 数据交互模块
const Log = require('../common/log');     // 日志模块

const HEADLESS = true;
const BROWSER_COUNT = 4;    // browser1111实例最大数
const MAX_PAGES = 1;        // 每个browser实例最多启动页数
const MAX_RUN_TIMES = 0;
const MAX_RUNNING_BROWSER = 1;
const TEST_BROSER_URL = GOOGLE_URLS[0] + '/search?hl=en&q=rosegal';


class Dispatcher {
	constructor() {
		this.browsers = [];
		this.waitForStore = [];
		this.queueStore = [];
		this.initBrowsersState = false;
		this.createBrowsers();
		this.sleepTime = 0;
	}
	
	async createBrowser() {
		let browser = await puppeteer.launch({
			headless: HEADLESS,
			// args: ['--proxy-server=' + await getPublicIp()]
		});
		return browser;
	}

	async createBrowsers() {
		let prBrowsers = [];
		for (let i = 0; i < BROWSER_COUNT; i++) {
			prBrowsers = [...prBrowsers, this.createBrowser()];
		}
		try {
			const res = await Promise.all(prBrowsers);
			this.browsers = await res.map(async it => ({ status: -1, runTimes: 0, browser: it, pages: await this.createPages(it) }))
			this.browsers = await Promise.all(this.browsers);
			this.initBrowsersState = true;
			console.log('initial ready------------')
		} catch (err) {
			console.error(err);
		}
	}
	
	async createPage(browser) {
		return await browser.newPage();
	}

	async createPages(browser){
		let pages = [];
		let prPages = [];
		for (let i = 0; i < MAX_PAGES; i++) {
			prPages = [...prPages, this.createPage(browser)];
		}
		try {
			const res = await Promise.all(prPages);
			return res.map(it => ({status: -1, page: it}));
		} catch (err) {
			console.error(err);
		}
	}

	async isBlockedByGoogle(page) {
		const pageUrl = await page.url();
		console.log('isBlockedByGoogle------', pageUrl.startsWith('https://ipv4.google.com'))
		return pageUrl.startsWith('https://ipv4.google.com')
	}

	async isBrowserCanRun(page) {
		try {
			await page.goto(TEST_BROSER_URL, LOADOPTS);			
			const isBlocked = await this.isBlockedByGoogle(page);
			if( !isBlocked ) await page.close();
			return !isBlocked;
		} catch (err) {
			console.log('page goto error','isBrowserCanRun--------')
			return false;
		}
	}

	busyBrowserCount() {
		return this.browsers.reduce((a, it) => { const b = it.status === 1 ? 1 : 0; return a + b; }, 0);
	}

	async handlePuppeteerCore() {
		while(!this.initBrowsersState)  await timeout(500);
		const { browsers } = this;
		let page;
		let hasFree = false;
		if (this.busyBrowserCount() > MAX_RUNNING_BROWSER) return false;

		this.browsers = browsers.map((it, i) => {
			if (!hasFree && 'pages' in it && it.status === -1 && it.runTimes <= MAX_RUN_TIMES) {
				hasFree = it.pages.some((it2, j) => {
					if(it2.status === -1) {
						page = { page: it2.page, index: [i, j] };
						it.pages[j].status = 1;
						it.runTimes++;
						return true;
					}
				});
				// 不存在正在执行的page，此browser空闲
				if(hasFree) it.status = 1;      
			}
			return it;
		});
		console.log(page.index , 'has return page-------------')
		return page;
	}

	isThisBrowserFree(i) {
		const browser = this.browsers[i];
		const isHasBusy = it => it.status === 1;
		return !browser.pages.some(isHasBusy);
	}

	async run(data, isFirstRun = true) {					
		const page = await this.handlePuppeteerCore();
		await timeout(Math.random() * 500 + 8000);		
		if(!page) {
			this.waitForBrowserFree(data);
		}else {
			console.log('hasPageRun---------------')
			try {		
				if(this.sleepTime > 0) {
					await timeout(this.sleepTime);
					this.sleepTime = 0;
				}
				if(isFirstRun) this.setQueueStore({ data: data, status: -2, startTime: new Date().getTime(), coreIndex: page.index });
				const timer = setTimeout(() => {
					this.waitForBrowserFree(data);					
					this.resetStateAfterRun(page.index);
				}, 180000);	
				const res = await new Worker().run(data, page.page);
				clearTimeout(timer);
				this.resetStateAfterRun(page.index);
				await Ajax.handlePostResult(this.exChangeReturnData(res, data));    // 提交结果数据
				Log.addLogs(res, data);
			} catch (err) {
				console.error(err);
				const [i, j] = page.index;				
				if(err === -1) {
					await this.changeProxy(page.index);
					await timeout(Math.random() * 500 + 3000);
					// 取出当前browser重启前运行中的页面, 返回运行的Promise数组
					const pmAdSpiderRun = await this.queueStore.filter(it => it.coreIndex[0] === i && it.status === -2).map(async (it2, k) => await this.run(it2.data, false));					
					await Promise.all(pmAdSpiderRun);
				}
			}
		}
	}

	resetStateAfterRun(index) {
		this.removeQueueStore(index);
		this.handleBrowserState(index);
		this.dispatchWaitForRunData();  // 运行等待队列中
	}

	async handleBrowserState([i, j]){
		const browser = this.browsers[i];
		browser.pages[j].status = -1;
		if (this.isThisBrowserFree(i)) browser.status = -1;
		if (browser.runTimes > MAX_RUN_TIMES && browser.status === -1) await this.changeProxy([i]);		
	}

	setQueueStore(el) {
		const { queueStore } = this;		
		this.queueStore = [...queueStore, el];
	}

	removeQueueStore(index) {
		const { queueStore } = this;
		this.queueStore = queueStore.filter(it => it.coreIndex.toString() !== index.toString());
	}

	async changeProxy([i]) {
		console.log('changeProxy----------',i)
		const { browsers } = this;
		const { pages } = browsers[i];
		const pmPages = pages.map(it => it.page.close());
		try {
			await Promise.all(pmPages);
			await this.browsers[i].browser.close();
			await timeout(1500);
		} catch (err) {
			console.error(err);
		}
		this.browsers[i].browser = await this.createBrowser();
		this.browsers[i].pages = await this.createPages(this.browsers[i].browser);
		this.browsers[i].status = -1;
		this.browsers[i].runTimes = 0;
	}

	waitForBrowserFree(data) {
		const { waitForStore } = this;
		console.log('waitForBrowserFree----');
		this.waitForStore = [...waitForStore, data];
	}

	dispatchWaitForRunData(){
		const { waitForStore } = this;
		console.log(waitForStore, 'dispatchWaitForRunData----------', '<<', waitForStore.length, '>>');
		if(waitForStore.length === 0) return;
		const waitLen = waitForStore.length;
		if(waitLen === 0) {
			return;
		} else if(waitLen % 10 === 0) {
			this.sleepTime = Math.random() * 120000 + 120000; 
		} 
		waitForStore.forEach((it, i) => { 
			this.waitForStore.splice(i, 1); 
			this.run(it);
		});
	}

	exChangeReturnData(res, param) {
		const resData = res.data.map(it => ({
			keyword: res.key,
			domainSign: param.domainSign,
			advertisingWord: it.title,
			advertisingContent: it.body,
			requestUrl: it.url,
			source: "来源---",
			account: "账号---",
			email: "email---",
			execTime: it.execTime,
			country: it.country,
			redirections: it.redirections.map(_it => ({ url: _it.url })),
			userAgent: param.userAgent,
			lkid: it.lkid,
			fromPage: it.fromPage
		}));
		const { id } = param;
		return {resData, id};
	}


}


const _Spider = new Dispatcher();

module.exports = _Spider;
