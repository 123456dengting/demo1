const Utils = require('../utils/utils');
const dispatcher = require('./dispatcher');
/**
 * 接口数据分发处理
 * 
 * @class Entry
 */
class Entry {
    constructor() {

    }

    async dispatchTask(opts) {
        dispatcher.run(opts);       // 执行任务
        return { code: 0, msg: 'success', data: {} };
    }

    async apiEntry(opts, name) {
        return this[name](opts);
    }

}

module.exports = new Entry();