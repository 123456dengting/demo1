const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, HEADLESS, TYPE_2_USERAGENT, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS, COUNTRY_TO_GURL } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, moment } = require('../utils/utils');
const devices = require('puppeteer/DeviceDescriptors');
const SELECTOR = {
    'PC': {
        adBlock: '.ads-ad',
        adTitle: '.ad_cclk',
        adBody: '.ellip',
        adUrl: '.ad_cclk h3 a:not([style*="display:none"])',
        nextPage: '.b.navend:last-child a'

    },
    'iPad': {
        adBlock: '.ads-ad',
        adTitle: '.ad_cclk',
        adBody: 'div.ads-creative',
        adUrl: '.ad_cclk a:not([style*="display:none"])',
        nextPage: '#sfooter .ksb:last-child'

    },
    'mobile': {
        adBlock: '.ads-ad',
        adTitle: '.ad_cclk',
        adBody: 'div.ads-creative',
        adUrl: '.ad_cclk a:not([style*="display:none"])',
        nextPage: '#sfooter .ksb:last-child'
    },
};
class Worker {
    constructor() {
        this.runResolve = null;
        this.runReject = null;
        this.domainSign = 'rosegal';      // 网站标识名
        this.signToJump = false;    // 记录跳转标识       
        this.redirections = [];    // 记录跳转url
    }

    async getAdText(page) {
        console.log('run text')
        return await page.evaluate(opts => {
            const [ domainSign, userAgent, SELECTOR ] = opts;
            let eAds = document.querySelectorAll(SELECTOR[userAgent].adBlock);
            let adTitle = [], adBody = [], adLink = [];
            for (var i = 0, len = eAds.length; i < len; i++) {
                var it = eAds[i];
                var eAdTitle = it.querySelector(SELECTOR[userAgent].adTitle).innerText;
                if (eAdTitle.toLowerCase().indexOf(domainSign) > -1) {
                    var eAdBody = it.querySelectorAll(SELECTOR[userAgent].adBody);
                    adTitle.push(eAdTitle);
                    adBody.push(Array.from(eAdBody).reduce((a, b) => a += b.innerText, ''));
                }
            }
            return { title: adTitle, body: adBody };
        }, [this.domainSign, this.param.userAgent, SELECTOR]);
    }

    async secureClick(el, page) {
        const Mouse = page.mouse;
        await el.hover();
        const { x, y } = await el.boundingBox();
        await Mouse.move(x, y);
        await timeout(Math.random() * 300);
        await Mouse.click(x, y);
    }

    async getAdUrl(page, reject) {
        console.log('run url')
        const { userAgent } = this.param;
        const eAds = await page.$$(SELECTOR[userAgent].adBlock);
        let urls = [];

        for (let i = 0; i < eAds.length; i++) {
            await timeout(Math.random() * 500 + 3500);            
            const eAds = await page.$$(SELECTOR[userAgent].adBlock);
            const urlText = eAds.length - 1 < i ? '' : await page.evaluate(el => el.innerText, await eAds[i].$(SELECTOR[userAgent].adTitle));

            if (urlText.toLowerCase().indexOf(this.domainSign) > -1) {
                const el = await eAds[i].$(SELECTOR[userAgent].adUrl);
                const nowUrl = await page.url();
                console.log(nowUrl,'getUrl nowUrl------------------')
                await timeout(Math.random() * 1000);
                this.signToJump = true;
                await this.secureClick(el, page);
                await page.waitForNavigation({ timeout: 0 });
                await timeout(Math.random() * 500 + 200);
                let waitSumTime = 0;
                while (this.signToJump && waitSumTime < 20000) {
                    await timeout(50);
                    waitSumTime += 50;
                }
                const urlParam = this.redirections.length > 0 ? this.redirections.splice(-1, 1)[0] : { url: '', params: '' };
                const timeStamp = new Date().getTime();
                const redirections = this.redirections;
                const execTime = moment('Y-M-D h:m:s', timeStamp);
                urls.push({ timeStamp, execTime, ...urlParam, waitSumTime, redirections });
                // console.log(urls, 'urls')
                this.redirections = [];
                try {
                    await page.goto(nowUrl, LOADOPTS);
                    if (await this.isBlockedByGoogle(page)) {
                        console.log('ipv4--------------------------')
                        reject(-1);
                        return;
                    }
                } catch (err) {
                    console.log(err, '---goto nowUrl error');
                    return false;
                }
            }
            await timeout(200);
        }
        return urls
    }

    async isBlockedByGoogle(page) {
        const pageUrl = await page.url();
        return pageUrl.startsWith('https://ipv4.google.com');
    }

    getUserAgent(UAType) {
        switch (UAType) {
            case 'iPad':
                return devices['iPad'].userAgent;
                break;
            case 'mobile': 
                return devices['iPhone 6'].userAgent;
                break;
            default:
                return TYPE_2_USERAGENT['PC'];
                break;
        }
    }

    async run(param, page) {
        this.param = param;
        this.domainSign = param.domainSign ? param.domainSign.toLowerCase() : this.domainSign;
        const startTime = new Date().getTime();
        return new Promise(async (resolve, reject) => {
            const timer = setTimeout(() => { reject(-1); return false;}, 180000);
            await page.setUserAgent(this.getUserAgent(param.userAgent)); // 设置ua
            page.on('request', async req => {
                if (this.signToJump && req.resourceType === "document") {
                    let arrStr = req.url.split('?');
                    arrStr.splice(0, 1);
                    this.redirections.push({ url: req.url, params: paramsStringToJson(arrStr.join("")) });
                    if (req.url.split('?')[0].indexOf(this.domainSign) !== -1) this.signToJump = false;     //获取到重定向终点之后改变标识
                }
            })

            const googleUrl = COUNTRY_TO_GURL[param.country] + '/search?hl=en&q=' + param.keyword;
            console.log(googleUrl, 'googleUrl-----------------')
            try {
                await page.goto(googleUrl, LOADOPTS);
                if(await this.isBlockedByGoogle(page)) {
                    console.log('ipv4--------------------------')
                    reject(-1);
                    return ;
                }
            } catch (e) {
                console.error(e);
                console.log('Catching goto url error')
                reject(-1);
                return ;
            }

            await timeout(Math.random() * 200 + 1000);
            const pageUrl = await page.url();
            let info = [];
            const { userAgent } = param;
            for (let i = 0; i < 5; i++) {
                await timeout(Math.random() * 500 + 500);
                if(i > 0){
                    try {
                        await page.click(SELECTOR[userAgent].nextPage);
                    } catch (err) {
                        resolve({ key: param.keyword, data: info });
                    }
                    // await page.waitForNavigation(LOADOPTS);  // wait next page loaded   
                }
                await timeout(Math.random() * 500 + 2500);
                const adText = await this.getAdText(page);
                console.log(adText,'adtext------------------------')
                const adUrl = await this.getAdUrl(page, reject);
                if(!adUrl) { reject(-1); return ;}
                adUrl.forEach((it, j) => {
                    const domain = it.url.split('/')[0] + '//' + it.url.split('/')[2];
                    const lkid = it.params.lkid ? it.params.lkid : '';
                    const title = adText.title[j];
                    const body = adText.body[j];
                    const fromPage = i + 1;       // 搜索页码
                    const country = param.country;    // 当前检测的国家
                    info.push({ domain, title, body, country, lkid, fromPage, ...it });
                })
            }
            if (await this.isBlockedByGoogle(page)) {
                console.log('ipv4--------------------------')
                reject(-1);
                return;
            }
            resolve({ key: param.keyword, data: info });
            clearTimeout(timer);
            console.log(new Date().getTime() - startTime);
        })
    }

}

module.exports = Worker;