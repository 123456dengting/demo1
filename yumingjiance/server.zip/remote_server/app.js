const express = require('express');
const api = require('./routes/api');
const app = express();
app.use(api);
app.get('/', (req, res) => res.send('Hello World!'))

app.listen(30001, () => console.log('Example app listening on port 30001!'))