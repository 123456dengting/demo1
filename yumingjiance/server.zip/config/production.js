module.exports = {
    url: 'http://10.40.6.82',
    port: '8010',
    otherPort: '30001'
}