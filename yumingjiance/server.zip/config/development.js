module.exports = {
    url: 'http://10.35.1.88',
    port: '8081',
    otherServer: '127.0.0.1',
    otherPort: '30001'
}