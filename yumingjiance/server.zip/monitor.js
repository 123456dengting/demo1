const path = require('path');
const config = require('./config');     //基础配置参数
const { TIMEOUT_RUN, HEADLESS, UA, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, deepObj2array, moment, isObject } = require('./utils/utils');
const rp = require('request-promise');   // request 支持promise版本
const schedule = require('node-schedule');
const AdDispatcher = require('./ad_monitor/Dispatcher');
const JSEntry = require('./js_monitor/Entry');
const Ajax = require('./common/Ajax');  // 数据交互模块
const Message = require('./common/message');  // 消息反馈模块
const mockData = require('./mock/mock');
var amqp = require('amqplib/callback_api');
//socket.io
var api = require('./routes/api');
var cors = require('./middleware/cors');
var app = require('express')();
var svr = require('http').Server(app);
var io  = require('socket.io')(svr);
svr.listen(3009); // socket服务
app.use(cors);   
app.use('/api', api);
var server = app.listen('3007', function () {
    console.info('Express server listening on port ' + server.address().port);
})
const isMock = true;  // 是否启用mockData
/**
 * @description 广告检测任务模块
 * @author xxwait 
 * @class Monitor
 */
class Monitor extends Message {
    constructor(){
        super('Monitor');
        this.init();         // 初始化
        this.initSocket();       // 初始化socket
    }
    
    initData() {
        this.jobs = [];          // 存储定时任务数组
        this.js = {
            jobs: []    // 存储JS定时任务数组
        };         
        this.socket = {};
        this.servers = [ // 这个东西没有用
            {
                ip: '52.71.18.12',
                country: '美国',
                lastTaskTime: 0,
            },
            {
                ip: '52.55.146.195',
                country: '美国',
                lastTaskTime: 0,
            },
            {
                ip: '52.56.77.53',
                country: '英国',
                lastTaskTime: 0,
            },
            {
                ip: '52.56.128.225',
                country: '英国',
                lastTaskTime: 0,
            },
        ].map((it, key) => ({ ...it, key }));

        this.queueName = 'ars_ad';    // 队列名称
        
    }

    async init () {
        this.initData();
        // this.initRabbitmq();        
        await this.initAdMonitor();     // 初始化adMonitor
        await this.initJSMonitor();     // 初始化adMonitor
    }
    
    async initAdMonitor() {
        const paramData = isMock ? mockData : await Ajax.getParams(); 
        this.addJobs(this.jobs, paramData);
    }

    async initJSMonitor() { 
        const paramData = await Ajax.getJSMonitorParams();
        if (paramData) JSEntry.do(paramData);
        else this.error('JSmonitor init failed');
    }

    /**
     * @method editJob
     * @description 编辑定时任务
     * @param { object } jobs 可编辑任务对象
     * @param { object } keyword 配置数据对象
     */
    editJob(jobs, keyword) {
        this.removeJob(jobs, keyword.id);
        this.addJobs(jobs, [keyword]);
    }

    /**
     * @method removeJob
     * @description 删除某个定时任务
     * @param { object } jobs 
     * @param { array | string } id 
     */
    removeJob(jobs, id) {
        if (Array.isArray(id)) {
            id.map(it => this.removeJob(jobs, it));
        } else {
            jobs.forEach((it, i) => {
                if (it.id === id) {
                    it.job.cancel();
                    jobs.splice(i, 1);
                }
            });
        }
    }

    /**
     * @method createJob
     * @description 创建定时任务   
     * @param { string } time 定时执行时间 
     * @param { object } keyword 配置信息 
     * @returns 返回定时任务对象
     */
    createJob(time, keyword) {
        console.log(time, moment('Y-M-D h:m:s'))
        return schedule.scheduleJob(time, async () => {
            try {
                const pmRun = await this.handleAdMonitorParam(keyword, time);
                try {
                    await Promise.all(pmRun);
                } catch (err) {
                    console.error(err)
                }
            } catch (err) {
                console.error(err);
            }
        })
    }

    /**
     * @method addJobs
     * @description 新增定时任务并添加到jobs对象
     * @param { object } jobs 
     * @param { object } keywords 
     */
    addJobs(jobs, keywords, isRunNow) {
        keywords.forEach(it => {
            if (isRunNow) {
                jobs.push({ job: this.createJob(this.createRunNowTime(), it), id: it.id });                
            }else {
                it.execTime.forEach(it2 => {
                    jobs.push({ job: this.createJob(this.formatTimeParam(it2.time), it), id: it.id });
                })
            }
        });
    }
 
    /**
     * @method initSocket
     * @description 初始化sockect，链接并监听客户端socket
     * @memberof Monitor
     */
    initSocket(){
        io.on('connection', socket => {
            this.socket = socket;
            socket.on('client', this.onSocketAdMonitor.bind(this));
            socket.on('client:jsmonitor', this.onSocketJSMonitor.bind(this));
            socket.emit('server', { msg: 'Hello,This is server' });
        });
    }

    /**
     * @method onSocketAdMonitor
     * @description 处理adMonitor模块socket消息        
     * @param { object } req 收到消息
     * @param { function } cb callback函数 
     * @memberof Monitor
     */
    onSocketAdMonitor(req, cb) {
        const keyword = req.data.autoTest ? deepObj2array(req.data.autoTest.keyword, 'country', 'execTime', 'devices') : [];
        if (typeof cb === 'function') cb({ code: 100 });
        switch (req.actionId) {
            case 1:      // 添加新配置任务
                this.addJobs(this.jobs, keyword)
                break;  
            case 2:      // 修改配置任务
                this.editJob(this.jobs, keyword[0]);
                break;
            case 3:      // 删除配置任务
                this.removeJob(this.jobs, req.data);
                break;
            case 4:      // 立即运行某配置任务
                const isRunNow = true;
                const runData = deepObj2array(req.data, 'country', 'execTime', 'devices');
                this.addJobs(this.jobs, runData, isRunNow);
                break;
            default:
                break;
        }
    }

    /**
     * @method onSocketJSMonitor
     * @description 处理JSMonitor模块socket消息        
     * @param { object } req 收到消息
     * @param { function } cb callback函数 
     * @memberof Monitor
     */
    onSocketJSMonitor(req, cb) {
        const { actionId, id, tid, data } = req;
        if (typeof cb === 'function') cb({ code: 100 });
        JSEntry.do(data, actionId);
    }
    /**
     * @method handleAdMonitorParam
     * @description 处理adMonitor配置数据传入Dispatcher
     * @param { object } keyword 
     * @returns { <promise>array } 
     * @memberof Monitor
     */
    async handleAdMonitorParam(keyword) {// 任务入口

            return await keyword.country.map(async it => {
                return await keyword.devices.map(async it2 => {
                    const country = it.name;
                    const userAgent = it2.userAgent;
                    const originTime = moment('Y-M-D h:m:s'); // 获取格式化时间
                    const params = { ...keyword, country, userAgent, originTime };
                    // if(country === '美国' || country === '英国'){
                    //     console.log(this.servers, country, 'servers--------');
                    //     const { key, ip } = this.autoChooseServer(country);
                    //     this.updateServerRunTime(key);
                    //     // const res = await Ajax.sendTask(params, ip);
                    //     console.log('after send---------');
                    // }else {
                        return await AdDispatcher.run(params);
                    // }
                    // let s = 0; 
                    // // 等待60s初始化连接到rabbitmq
                    // while(!this.ch && s < 600) {
                    //     await timeout(100);
                    //     s++;
                    // }
                    // if(s === 1200) console.error('Rabbitmq server connect failed...');
                    // else this.ch.sendToQueue(this.queueName, new Buffer(JSON.stringify(params)), { persistent: true });
                })
            });
        
    }
    /**
     * @method autoChooseServer
     * @description 选择执行任务服务器
     * @param {string} [country='美国'] 
     * @memberof Monitor
     * @return { object } server
     */
    autoChooseServer(country = '美国') {
        return this.getEarliestServer(this.getServers(country));
    }
    /**
     * @method getServers
     * @description 根据国家获取服务器对象
     * @param {string} [country='美国'] 
     * @returns { array } servers
     * @memberof Monitor
     */
    getServers(country = '美国') {
        const isThisCountry = it => it.country === country;
        return this.servers.filter(isThisCountry);
    }

    /**
     * @method getEarliestServer
     * @description 获取最早服务器对象
     * @param {any} servers 
     * @returns {object} earliest server object
     * @memberof Monitor
     */
    getEarliestServer(servers) {
        const earliestTime = servers.reduce((pre, it) => pre > it.lastTaskTime ? it.lastTaskTime : pre, new Date().getTime());
        const isThisTime = it => it.lastTaskTime === earliestTime;
        return servers.find(isThisTime);
    }
    /**
     * @method updateServerRunTime
     * @description 更新服务器最后执行任务时间
     * @param {any} key 
     * @memberof Monitor
     */
    updateServerRunTime(key) {
        this.servers[key].lastTaskTime = new Date().getTime();
    }


    /**
     * @method createRunNowTime
     * @description 创建即刻运行时间
     * @param { number } afterTimes ms,默认3000
     * @returns { date } 标准时间
     * @memberof Monitor
     */
    createRunNowTime(afterTimes = 3000) {
        return new Date(new Date().getTime() + afterTimes);   // 返回ns后标准时间时间
    }

    /**
     * @method formatTimeParam
     * @description 转换时间格式为定时任务所需格式 '12:10:09' -> '09 10 12 * * *'
     * @param { string } time 
     * @returns { string } schedule time format
     * @memberof Monitor
     */
    formatTimeParam(time) {
        return time.split(":").reduce((a, b) => `${b} ${a}`, '') + '* * *';
    }
    /**
     * 初始化rabbitmq服务
     * 
     * @memberof Monitor
     */
    initRabbitmq() {
        amqp.connect('amqp://ars:ars123@123.58.55.162:5672', (err, conn) => {
            if (!err) {
                conn.createChannel(async (err, ch) => {
                    ch.assertQueue(this.queueName, { durable: false });
                    // Note: on Node 6 Buffer.from(msg) should be used
                    this.ch = ch;            // queue全局实例   
                    // await Utils.sleep(1000);
                    // let j = 0;
                    // while (j < 201) {
                    //     await Utils.sleep(Math.random() * 500 + 200);
                    //     const guid = Utils.guid();
                    //     console.log(` [x] Sent 'Hello World!' <${guid}> [${j}]`);
                    //     ch.sendToQueue(q, new Buffer(`<${guid}> Hello World! [${j}]`), { persistent: true });
                    //     j++;
                    // }
                    // conn.close(); process.exit(0)
                });
            } else {
                console.error(err);
            }
        });
    }
}

new Monitor();