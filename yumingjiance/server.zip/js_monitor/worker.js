const path = require('path');

const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, HEADLESS, UA, GOOGLE_URLS } = config;

const { timeout, readFilePromise, writeFilePromise, isObjectValueEqual, paramsStringToJson, kvArrayToObject, getMsgObject, moment, trim, isElementsInArray, guid, mkdirs } = require('../utils/utils');
const TIMEOUT = 120000;

const Message = require('../common/message');

/**
 * @description 执行JS检测任务过程模块
 * @author xxwait <zicong_s@163.com>
 * @class Worker
 */
class Worker extends Message{
    constructor() {
        super('Js-Worker');
        this.RUN_STEP = 1; //初始化阶段控制标志; step1: 收集非script返回。step2: 收集所有请求。step3: 截断请求    
        this.errorStore = [];    
        this.resNetWorkScripts = [];        
        this.arrScript = {};
    }

    async handleRequest(page, req) {
        switch (this.RUN_STEP) {
            case 4:
                const status = this.arrScript.codes.some( (it, i) => {
                    if (it.url === req.url && req.resourceType === 'script') {
                        req.respond({
                            status: 200,
                            contentType: 'text/plain',
                            body: it.code + ';(function(){console.log( \'*-._.-*.[id = ' + it.id + '] script run success\')})()'
                        });
                        this.arrScript.codes[i] = { ...this.arrScript.codes[i], ...{ status: 0 } };
                    }
                    return it.url === req.url && req.resourceType === 'script';
                })
                // 判断内敛script发出请求，并拦截
                !status ? req.continue() : '';
                break;
            case 2:
                // 过滤请求，检查需要验证的url => param

                page.tests.some((it, i) => {
                    if (trim(it.url.split('?')[0]) === trim(req.url.split('?')[0])) {
                        const paramsStr = req.method == 'POST' ? req.postData : req.url.split("?")[1];
                        const status = isElementsInArray(paramsStringToJson(paramsStr), kvArrayToObject(it.params));
                        status ? page.tests[i].result = true : '';
                        return status;
                    }
                });
                req.continue();
                break;
            default:
                req.continue();
                break;
        }
    }

    async handleResponse(res) {
        if (!res.ok) this.errorStore.push({ url: res.url, status: res.status, header: res.headers });
        const jsCode = await res.text();
        const req = res.request();
        if (req.resourceType === 'script') {
            if (this.RUN_STEP === 2 || this.RUN_STEP === 1) {
                this.resNetWorkScripts.push({ "url": res.url, "code": jsCode });
            }
        }
    }

    async handleRequestfailed(reqfa) {
        switch (this.RUN_STEP) {
            case 4:
                console.log(reqfa.url, 'error');
                break;
            default:
                break;
        }
    }
    async saveCodeAsFiles(code, initTimeStamp, codePath, guid) {
        try {
            mkdirs(codePath, async function () {
                const res = await writeFilePromise(code, codePath + '/' + guid + '.js');
            })
        } catch (err) {
            console.error(err);
            console.log('Save code Error!');
        }
    }
    async runPuppeteerSeparateTab(tab, page, tid) {
        return new Promise(async (resolve, reject) => {
            // 拦截请求并检测
            const startTime = new Date().getTime();   //超时记录开始
            const timer = setTimeout(() => { reject(-1) }, 120000);

            tab.setViewport({ width: 1200, height: 1600 });
            await tab.setRequestInterception(true);
            tab.on('requestfailed', this.handleRequestfailed.bind(this));

            // 截断request，返回注入script
            tab.on('request', this.handleRequest.bind(this, page));
            //收集请求response信息
            tab.on('response',this.handleResponse.bind(this));

            await tab.setJavaScriptEnabled(false);
            console.log('before goto')
            await tab.goto(page.url, { timeout: TIMEOUT, waitUntil: 'domcontentloaded' });
            await timeout(2000);            
            console.log('goto page success')
            // 设置执行javaScript环境为false，生成pid=0第一层级数组arrScript
            this.arrScript = await tab.$$eval('script', scripts => {
                let srcCount = 0;
                let exRes = [];
                const aScripts = Array.from(scripts);
                const res = aScripts.map((it, i) => {
                    it.hasAttribute('src') ? srcCount++ : exRes.push({ type: 'INLINE', key: i, code: it.textContent });
                    const code = it.hasAttribute('src') && (!it.hasAttribute('type') || (it.hasAttribute('type') && (it.type == 'text/javascript' || it.type == 'text/ecmascript'))) ? 'src:' + it.src : it.textContent;
                    const url = it.hasAttribute('src') ? it.src : '';
                    const isStartGTM = !it.hasAttribute('src') && it.textContent.toLowerCase().indexOf('gtm') > -1 ? true : '';
                    return { id: i + 1, code: code, url: url, pid: 0, status: 0, grade: 1, isStartGTM: isStartGTM, isGTM: isStartGTM };
                });
                return { count: srcCount, codes: res, res_exs: exRes };
            });
            await tab.setJavaScriptEnabled(true);
            this.RUN_STEP = 2;     // 页面重载，进入step2阶段
            try {
                await tab.reload({ waitUntil: 'domcontentloaded' });
            } catch (err) {
                console.error(err);
            }
            console.log('step-2 starting')
            await timeout(2000);  //触发step2阶段param检查的超时
            // 匹配代码块中的url
            this.resNetWorkScripts.forEach( (it, i) => {
                // 匹配网站url
                let domain = it.url.replace('src:', "").replace('http://', "").replace('https://', "").split('/')[0];
                this.arrScript.codes.forEach( (_it, j) => {
                    // 代码块匹配
                    if (_it.code.indexOf(domain) > -1 && _it.code.indexOf('script') > -1 && _it.code.indexOf('src') > -1 && _it.code.indexOf('createElement') > -1 && !_it.code.startsWith('src:')) {
                        const isGTM = (_it.pid === 0 && _it.isStartGTM) || _it.isGTM ? true : '';
                        this.arrScript.codes.push({ id: this.arrScript.codes.length + 1, code: it.code, url: it.url, pid: j + 1, status: -1, grade: _it.grade + 1, isStartGTM: '', isGTM: isGTM });
                    } else if (_it.code.startsWith('src:') && _it.url === it.url) {
                        this.arrScript.codes[j].code = it.code;
                    }
                })
            });
            
            console.log('step-2:', this.resNetWorkScripts.length);
            await tab.setJavaScriptEnabled(false);
            this.RUN_STEP = 3; // 页面重载，进入step-3
            try {
                await tab.reload({ waitUntil: 'domcontentloaded' });
            } catch (err) {
                console.error(err);
            }
            await timeout(2000);            
            await tab.setJavaScriptEnabled(true);

            await tab.evaluate(arrScript => {
                const oScripts = Array.from(document.querySelectorAll('script'));
                oScripts.forEach((it, i) => {
                    if (!it.hasAttribute('src') && (!it.hasAttribute('type') || (it.hasAttribute('type') && (it.type === 'text/javascript' || it.type === 'text/ecmascript')))) {
                        let id = -1;
                        const status = arrScript.codes.some(_it => {
                            id = _it.id;
                            return _it.code === it.textContent;
                        })
                        it.textContent += ';(function(){console.log( \'*-._.-*.[id = ' + id + '] script run success\')})()';
                    }
                })
            }, this.arrScript);

            const injectContent = await tab.content();

            this.RUN_STEP = 4;
            await tab.reload({ waitUntil: 'domcontentloaded' }); 
            await timeout(2000);

            await tab.evaluate(injectContent => {
                document.write(injectContent);
            }, injectContent);

            let consoleMsgs = {
                log: [],
                error: [],
                info: [],
                warning: []
            };
            tab.on('console', msg => {
                consoleMsgs[msg.type].push(msg.text);
                if (msg.type === 'log') {    //成功执行
                    const { text } = msg;
                    const id = parseInt(text.substring(text.indexOf('= ') + 1, text.indexOf(']')));
                    this.arrScript.codes.some((it, i) => {
                        if (it.id === id) {
                            this.arrScript.codes[i].status = 1;
                            return true;
                        }
                    });
                }
            })
            await timeout(2000);

            //去除未触发代码
            const initTimeStamp = new Date().getTime();
            const isStatus = it => it.status > 0;
            this.arrScript.codes = this.arrScript.codes.filter(isStatus).map(it => {
                const codePath = path.resolve(__dirname, config['DATA_PATH'], 'codes/' + moment('Y/M/D/') + initTimeStamp);
                const _guid = guid();
                it.codePath = 'codes/' + moment('Y/M/D/') + initTimeStamp + '/' + _guid + '.js';
                this.saveCodeAsFiles(it.code, initTimeStamp, codePath, _guid);
                return it;
            });
            console.log({ page: page, 'script_tree': this.arrScript, console_msgs: consoleMsgs });
            // await saveDataToJson({ page: page, 'script_tree': this.arrScript })
            resolve({ page: page, 'script_tree': this.arrScript, console_msgs: consoleMsgs });  // 返回数据
            clearTimeout(timer);
            await tab.close();

            //----------------------测试content

        })

    }


}

module.exports = Worker;