var path = require('path');
const config = require('../config');     //基础配置参数
const { TIMEOUT_RUN, UA, GOOGLE_URLS, PER_TAB_COUNT, LOADOPTS } = config.SPIDER;
const { timeout, readFilePromise, writeFilePromise, paramsStringToJson, getPublicIp, domain2Country, moment } = require('../utils/utils');
const TIMEOUT = 120000;
const Message = require('../common/message');
const Worker = require('./worker');
const Ajax = require('../common/ajax');
const puppeteer = require('puppeteer');
const Notification = require('../common/notification');
const BROWSER_COUNT = 2;    // browser实例最大数
const MAX_PAGES = 1;        // 每个browser实例最多启动页数
const MAX_RUN_TIMES = 0;
const MAX_RUNNING_BROWSER = 1;
const HEADLESS = false;
/**
 * @description 调度分配JS检测任务执行模块
 * @author xxwait <zicong_s@163.com>
 * @class Dispatcher
 */
class Dispatcher extends Message {

    constructor() {
        super('Js-Dispatcher');
        this.browsers = [];
        this.waitForStore = [];
        this.queueStore = [];
        this.initBrowsersState = false;
        this.createBrowsers();
    }

    async createBrowser() {
        let browser = await puppeteer.launch({
            headless: HEADLESS,
            // args: ['--proxy-server=' + await getPublicIp()]
        });
        return browser;
    }

    async createBrowsers() {
        let prBrowsers = [];
        for (let i = 0; i < BROWSER_COUNT; i++) {
            prBrowsers = [...prBrowsers, this.createBrowser()];
        }
        try {
            const res = await Promise.all(prBrowsers);
            this.browsers = await res.map(async it => ({ status: -1, runTimes: 0, browser: it }))
            this.browsers = await Promise.all(this.browsers);
            this.initBrowsersState = true;
            console.log('initial ready------------')
        } catch (err) {
            console.error(err);
        }
    }

    async createPage(browser) {
        return await browser.newPage();
    }

    async createPages(browser) {
        let pages = [];
        let prPages = [];
        for (let i = 0; i < MAX_PAGES; i++) {
            prPages = [...prPages, this.createPage(browser)];
        }
        try {
            const res = await Promise.all(prPages);
            return res.map(it => ({ status: -1, page: it }));
        } catch (err) {
            console.error(err);
        }
    }

    async isBlockedByGoogle(page) {
        const pageUrl = await page.url();
        console.log('isBlockedByGoogle------', pageUrl.startsWith('https://ipv4.google.com'))
        return pageUrl.startsWith('https://ipv4.google.com')
    }

    async isBrowserCanRun(page) {
        try {
            await page.goto(TEST_BROSER_URL, LOADOPTS);
            const isBlocked = await this.isBlockedByGoogle(page);
            if (!isBlocked) await page.close();
            return !isBlocked;
        } catch (err) {
            console.log('page goto error', 'isBrowserCanRun--------')
            return false;
        }
    }

    busyBrowserCount() {
        return this.browsers.reduce((a, it) => { const b = it.status === 1 ? 1 : 0; return a + b; }, 0);
    }

    async handlePuppeteerCore() {
        while (!this.initBrowsersState) await timeout(500);
        const { browsers } = this;
        let browser;
        let hasFree = false;
        if (this.busyBrowserCount() > MAX_RUNNING_BROWSER) return false;

        browsers.some((it, i) => {
            if(it.status === -1) {
                it.status = 1;
                it.index = i;
                browser = it;
                return true;
            }
        });
        return browser;
    }

    isThisBrowserFree(i) {
        const browser = this.browsers[i];
        const isHasBusy = it => it.status === 1;
        return !browser.pages.some(isHasBusy);
    }

    async handleBrowserState(i, j) {
        const browser = this.browsers[i];
        browser.pages[j].status = -1;
        if (this.isThisBrowserFree(i)) browser.status = -1;
        if (browser.runTimes > MAX_RUN_TIMES && browser.status === -1) await this.restartBrowser(i);
    }

    setQueueStore(el) {
        const { queueStore } = this;
        this.queueStore = [...queueStore, el];
    }

    removeQueueStore(index) {
        const { queueStore } = this;
        this.queueStore = queueStore.filter(it => it.coreIndex.toString() !== index.toString());
    }

    async restartBrowser(i) {
        console.log('restartBrowser----------', i)
        const { browsers } = this;
        const { pages } = browsers[i];
        const pmPages = pages.map(it => it.page.close());
        try {
            await Promise.all(pmPages);
            await this.browsers[i].browser.close();
            await timeout(1500);

        } catch (err) {
            console.error(err);
        }
        this.browsers[i].browser = await this.createBrowser();
        this.browsers[i].status = -1;
        this.browsers[i].runTimes = 0;
    }

    waitForBrowserFree(data) {
        const { waitForStore } = this;
        console.log('waitForBrowserFree----');
        this.waitForStore = [...waitForStore, data];
    }
	/**
	 * 判断与当前时间对比是否超时
	 * @param {string} timeOri 初始时间
	 * @param {number=} [timeoutCount=1800000] 时间差，默认30分钟
	 * @returns {boolean} 是否超时
	 * @memberof Dispatcher
	 */
    isTimeout(timeOri, timeoutCount = 1800000) {
        return new Date().getTime() - new Date(timeOri).getTime() > timeoutCount;
    }
    dispatchWaitForRunData() {
        const { waitForStore } = this;
        console.log(waitForStore, 'dispatchWaitForRunData----------')
        if (waitForStore.length === 0) return;
        waitForStore.forEach((it, i) => {
            this.waitForStore.splice(i, 1);
            if (!this.isTimeout(it.originTime))
                this.run(it);
            else    
                Notification.entry(it,'js');
        });
    }

    async run(data) {
        Notification.entry(data);
        return;
        const browser = await this.handlePuppeteerCore();
        if (!browser) {
            this.waitForBrowserFree(data);
        } else {
            this.info(data, 'run===============');
            return new Promise(async (resolve, reject) => {
                const resArrPromise = data.pages.map(async (it, i) => {
                    it.url = it.url.trim().length > 0 ? it.url : it.name;
                    const page = await browser.browser.newPage();
                    return new Worker().runPuppeteerSeparateTab(page, it);
                });
                const startTime = new Date().getTime();
                try {
                    const resAll = await Promise.all(resArrPromise);
                    browser.status = -1;
                    this.dispatchWaitForRunData();
                    const postData = this.handleResponseData({ result: resAll, data: data, startTime });
                    await Ajax.postJSMonitorResult(postData);
                    this.info(resAll, 'resAll---------', postData);
                } catch (error) {
                    await this.restartBrowser(browser.index);
                    this.waitForBrowserFree(data);
                    this.dispatchWaitForRunData();                    
                }
            });
        }
    }

    handleResponseData (resData) {
        const domain = resData.data.name;
        let pageUrls = [];
        let pageScripts = [];
        let scripts = [];
        const data = resData.result.map(_it => {
            pageUrls.push(_it.page.url);
            scripts.length > 0 ? pageScripts.push(scripts) : '';
            scripts = [];
            const pageId = _it.page.id.toString();
            return _it.script_tree.codes.map(it => {
                const shortCode = it.code.substr(0, 100) + '...';
                const id = it.id.toString();
                const pid = it.pid.toString();
                const level = it.grade.toString();
                const url = it.url.length === 0 ? 'INLINE' : it.url;
                const gtmStart = it.isStartGTM ? true : false;
                const gtmRef = it.isGTM ? true : false;
                const state = it.status.toString();
                const errorPath = '';
                const keyWord = shortCode;
                const codePath = it.codePath;
                scripts.push({ id, pageId, pid, level, url, gtmStart, gtmRef, state, errorPath, keyWord, codePath });
                return [domain, _it.page.url, it.id, it.grade, it.pid, it.isStartGTM, it.isGTM, it.url, shortCode];
            })
        })
        pageScripts.push(scripts);
        const webSiteId = resData.data.id;
        const pages = resData.data.pages.map((it, i) => {
            const gtmResults = resData.result[i].page.tests.map(it => ({ gtmResult: it.result ? true : false, gtmUrl: it.url.trim().length > 0 ? it.url : it.name }));
            const url = it.url.trim().length > 0 ? it.url : it.name;
            const id = it.id;
            const date = resData.startTime;
            const scripts = pageScripts[i];
            return { id, webSiteId, gtmResults, url, date, scripts };
        });
        return {
            id: webSiteId,
            website: resData.data.name,
            pages
        }
    }

}


module.exports = new Dispatcher();
