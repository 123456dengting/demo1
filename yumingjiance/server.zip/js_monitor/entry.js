const schedule = require('node-schedule');
const Dispatcher = require('./dispatcher');

const config = require('../config');     //基础配置参数
const { HEADLESS } = config.SPIDER;
const { getPublicIp, moment, deepObj2array } = require('../utils/utils');
const BROWSER_COUNT = 4;    // browser实例最大数
const MAX_PAGES = 1;        // 每个browser实例最多启动页数
/**
 * @description puppeteer调用模块
 * @author xxwait <zicong_s@163.com>
 * @class Entry
 */
class Entry {
    constructor() {
        this.jobs = [];
        this.callback = () => { };
    }

    do(param, actionId = 0) {
        switch (actionId) {
            case 1:      // 添加新配置任务
                this.addJob(this.jobs, param)
                break;
            case 2:      // 修改配置任务
                this.editJob(this.jobs, param);
                break;
            case 3:      // 删除配置任务
                this.removeJob(this.jobs, param);
                break;
            case 4:      // 立即运行某配置任务        
                const runData = deepObj2array(param, 'pages', 'execTimes', 'tests', 'params');
                this.addRunNowEntrys(this.jobs, runData);
                break;
            default:
                this.addJobs(this.jobs, param);
                break;
        }
    }

    /**
     * @method editJob
     * @description 编辑定时任务
     * @param { object } jobs 可编辑任务对象
     * @param { object } keyword 配置数据对象
     */
    editJob(jobs, keyword) {
        this.removeJob(jobs, keyword.id);
        this.addJob(jobs, keyword);
        
    }

    /**
     * @method removeJob
     * @description 删除某个定时任务
     * @param { object } jobs 
     * @param { array | string } id 
     */
    removeJob(jobs, id) {
        if (Array.isArray(id)) {
            id.map(it => this.removeJob(jobs, it));
        } else {
            jobs.forEach((it, i) => {
                if (it.id === id) {
                    it.job.cancel();
                    jobs.splice(i, 1);
                }
            });
        }
    }

    /**
     * @method createJob
     * @description 创建定时任务   
     * @param { string } time 定时执行时间 
     * @param { object } keyword 配置信息 
     * @returns 返回定时任务对象
     */
    createJob(time, keyword) {
        console.log(time, moment('Y-M-D h:m:s'));
        return schedule.scheduleJob(time, async () => {
            keyword = {...keyword, originTime: moment('Y-M-D h:m:s')}
            this.handleMonitorParam(keyword);
        })
    }

    /**
     * @method addJobs
     * @description 新增定时任务并添加到jobs对象
     * @param { object } jobs 
     * @param { object } keywords 
     */
    addJobs(jobs, keywords) {
        keywords.forEach(it => {
            this.addJob(jobs, it);
        });
    }

    addJob(jobs, keyword) {
        if(!keyword.pages || !Array.isArray(keyword.pages) || keyword.pages.length === 0) return;
        keyword.execTimes.forEach(it2 => {
            jobs.push({ job: this.createJob(this.formatTimeParam(it2.time), keyword), id: keyword.id });
        });
    }

    /**
     * @method addJobs
     * @description 新增定时任务并添加到jobs对象
     * @param { object } jobs 
     * @param { object } keywords 
     */
    addRunNowEntrys(jobs, keywords) {
        keywords.forEach(it => {
            jobs.push({ job: this.createJob(this.createRunNowTime(), it), id: it.id });
        });
    }

    /**
     * @method createRunNowTime
     * @description 创建即刻运行时间
     * @param { number } afterTimes ms,默认3000
     * @returns { date } 标准时间
     * @memberof Entry
     */
    createRunNowTime(afterTimes = 3000) {
        return new Date(new Date().getTime() + afterTimes);   // 返回ns后标准时间时间
    }

    /**
     * @method handleMonitorParam
     * @description 处理adMonitor配置数据传入Dispatcher
     * @param { object } params 
     * @returns { <promise>array } 
     * @memberof Entry
     */
    async handleMonitorParam(params) {
        Dispatcher.run(params);
    }

    /**
     * @method formatTimeParam
     * @description 转换时间格式为定时任务所需格式 '12:10:09' -> '09 10 12 * * *'
     * @param { string } time 
     * @returns { string } schedule time format
     * @memberof Entry
     */
    formatTimeParam(time) {
        return time.split(":").reduce((a, b) => `${b} ${a}`, '') + '* * *';
    }

}

module.exports = new Entry();