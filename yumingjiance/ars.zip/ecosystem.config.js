module.exports = {
  apps: [
    {
      name: "monitor",
      script: "./server/monitor.js",
      watch: true,
      ignore_watch: ["[\/\\]\./", "./server/node_modules", "./server/logs", "./server/bin", "./server/data", "./server/public", "./server/views", "./build", "./server.js", "node_modules"],
      env: {
        "NODE_ENV": "development",
      },
      env_production: {
        "NODE_ENV": "pro"
      }
    },
    {
      name: "server",
      script: "./server.js",
      watch: true,
      ignore_watch: ["[\/\\]\./", "node_modules", "server"],
      env: {
        "NODE_ENV": "development",
      }
    }
  ]
}