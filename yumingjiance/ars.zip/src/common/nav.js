import asyncComponent from '../Components/AsyncComponent'

export const menusData = ( props ) => [
    {
        component: '',
        layout: 'BaseLayout',
        path: '/',
        children: [
            {
                name: '谷歌广告监测',
                path: 'ad-monitor',
                icon: 'google',
                children: [
                    {
                        name: '关键字自动监测结果',
                        path: 'result',
                        component: asyncComponent(props, () => import('../Routes/AdMonitor/Result'))
                    },
                    {
                        name: '关键字列表',
                        path: 'configure',
                        component: asyncComponent(props, () => import('../Routes/AdMonitor/Configure'))
                    },
                    {
                        name: '添加关键字',
                        path: 'add-configure',
                        component: asyncComponent(props, () => import('../Routes/AdMonitor/AddConfigure'))
                    }
                ]
            },
            {
                name: '网站JS监测',
                path: 'js-monitor',
                icon: 'chrome',
                children: [
                    {
                        name: '监测结果',
                        path: 'result',
                        component: asyncComponent(props, () => import('../Routes/JsMonitor/Result'))
                    },
                    {
                        name: '配置列表',
                        path: 'configure',
                        component: asyncComponent(props, () => import('../Routes/JsMonitor/Configure'))
                    },
                    {
                        name: '添加配置',
                        path: 'add-configure',
                        component: asyncComponent(props, () => import('../Routes/JsMonitor/AddConfigure'))
                    }
                ]
            },
            {
                name: '消息订阅中心',
                path: 'message',
                icon: 'message',
                children: [
                    {
                        name: '订阅列表',
                        path: 'list',
                        component: asyncComponent(props, () => import('../Routes/Message/Configure'))
                    },
                    {
                        name: '订阅设置',
                        path: 'setting',
                        component: asyncComponent(props, () => import('../Routes/Message/Setting'))
                    }
                ]
            }
        ]
    },
    {
        component: '',
        layout: 'UserLayout',
        path: 'user',
        children: [
            {
                name: '用户模块',
                path: 'user',
                icon: '',
                children: [
                    {
                        name: '登录',
                        path: 'login',
                        component: asyncComponent(props, () => import('../Routes/User/Login'))
                    }         
                ]
            }
        ]
    }

]