import React from 'react';
import ReactDOM from 'react-dom';
import { Route, Switch } from 'react-router';
import { BrowserRouter } from 'react-router-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
// import createBrowserHistory from 'history/createBrowserHistory';
import axios from 'axios';
import { message } from 'antd';
import { SocketProvider } from 'socket.io-react';
import io from 'socket.io-client';
const IS_DEV = true;
window.baseConfigs = {
    IS_DEV: IS_DEV,
    API_URL: IS_DEV ? 'http://10.35.1.88:8081/api/ArsFunction' : 'http://10.40.6.82:8010/api/ArsFunction',
    SOCKET_URL: IS_DEV ? 'http://127.0.0.1:3009' : 'http://10.40.2.68:3009',
}

const configs = window.baseConfigs;

const socket = io.connect(configs.SOCKET_URL);
// const socket = {};
axios.defaults.baseURL = configs.API_URL;

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
message.config({
    top: 200,
    duration: 1.5,
});
ReactDOM.render((
    <SocketProvider socket={socket}>
        <BrowserRouter>  
            <Switch>
                <Route path="/" render={props => <App {...props} />} />
            </Switch>
        </BrowserRouter>
    </SocketProvider>
), document.getElementById('root'));  
registerServiceWorker();
