import React, { Component } from 'react';
import { Layout, Input, Card, Button, message, Spin, Checkbox, Form } from 'antd';
import './Setting.css';
import * as Utils from '../../utils/utils';
import axios from "axios";
const CheckboxGroup = Checkbox.Group;
const { Content } = Layout;
const FormItem = Form.Item;
const styleCard = {
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
};
const styleForm = {
    margin: '0 auto',
    marginTop: 8,
    width: '80%',
    background: '#fff',
    padding: '20px 0 20px 80px'
};
const formItemLayout = {
    labelCol: {
        xs: { span: 4 },
        sm: { span: 4 },
    },
    wrapperCol: {
        xs: { span: 8 },
        sm: { span: 8 },
    },
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 16,
            offset: 8,
        },
    },
};

const checkboxChannelOptions = [
    { label: 'RTX', value: 'rtx' },
    { label: '邮件', value: 'email' },
    { label: '微信', value: 'wechat' },
];

class Setting extends Component {
    state = {
        isSpinning: false,
        subscriber: { name: '', unique_id: '' },
        adCheckboxOptions: [],
        jsCheckboxOptions: [],
        adChecked: [],
        jsChecked: [],
        channels: [],
        isAdShow: false,
        isJsShow: false,
        isEdit: false,
    }

    componentDidMount = async() => {
        console.log(this.state, this.props);
        this.setState({isSpinning: true});
        const resData = await this.getData();
        const adCheckboxOptions = Utils.deepObj2array(resData[0].data.data.list.keyword)
                                        .map(it => ({label: it.keyword, value: it.id}));
        const jsCheckboxOptions = Utils.deepObj2array(resData[1].data.data.list.website)
                                    .map(it => ({ label: it.name, value: it.id }));
        const { location: { state } } = this.props;
        if(Utils.isObject(state)) {
            console.log(isEdit, 'isEdit------')
            const isEdit = true;
            const arrayId = it => it.id;        
            const { keyword, website } = state.subDetail;    
            const adChecked = keyword.map(arrayId);
            const jsChecked = website.map(arrayId);
            const isAdShow = keyword.length > 0; 
            const isJsShow = website.length > 0; 
            const channels = state.channels;
            const subscriber = state.subscriber;
            this.setState({ isEdit, adChecked, jsChecked, channels, subscriber, isAdShow, isJsShow });
        }
        this.setState({adCheckboxOptions, jsCheckboxOptions}, () => this.setState({isSpinning: false}));
    }
    
    getData = async () => {
        const pmGetAdMonitorKeyword = axios.post('', Utils.json2PostData({ actionid: 1001, noat: true }));
        const pmGetJsMonitorKeyword = axios.post('', Utils.json2PostData({ actionid: 17, noat: true }));
        return await Promise.all([pmGetAdMonitorKeyword, pmGetJsMonitorKeyword]);
    }

    handleSubmit = e => {
        e.preventDefault();
        let { isEdit, adChecked, jsChecked, subscriber, isAdShow, isJsShow, channels } = this.state;
        const { history } = this.props;
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                const objId = it => ({id: it});
                const keyword = isAdShow ? adChecked.map(objId) : [];
                const website = isJsShow ? jsChecked.map(objId) : [];
                const postData ={ actionid: "2021", noat: true, push_person: JSON.stringify(subscriber), push_type: JSON.stringify(channels), keyword, website };
                if (isEdit) {
                    postData.id = history.location.state.id;    // 编辑状态提交数据带入id
                }
                this.setState({ isSpinning: true });
                const res = await axios.post('', Utils.json2PostData(postData));
                this.setState({ isSpinning: false }, async () => {
                    await Utils.timeout(500);
                    if (res.data.code === 1) {
                        message.success(res.data.msg, () => history.push('/message/list', {}));
                        // const website = isEdit ? res.data.data.Action.website : res.data.data.webScriptTest.website;
                        // const sendData = Utils.deepObj2array(website, 'pages', 'execTimes', 'tests', 'params')[0];
                        // const emitData = isEdit ? { actionId: 2, data: sendData } : { actionId: 1, data: sendData };
                        // socket.emit('client:jsmonitor', emitData, async (data) => {
                        //     await Utils.timeout(500);
                        //     if (data.code === 100) this.props.openNotification('服务器配置已更新');
                        // });
                    } else {
                        message.error(res.data.msg)
                    }
                });
            } else {
                const k = Object.keys(err)[0];
                message.error(err[k].errors[0].message);
            }
        });
    }

    onMonitorCheckboxChange = (e) => {
        const name = e.target.value;
        const value = e.target.checked;
        this.setState({[name]: value});
    }

    onKeywordCheckboxChange = (name, checkedValues) => {
        this.setState({[name]: checkedValues});
    }

    onChannelCheckboxChange = (checkedValues) => {
        const channels = checkedValues;
        this.setState({channels});
    }
    
    handleSubscriber = (type, e) => {
        const { value } = e.target;
        let { subscriber } = this.state;
        subscriber[type] = value;
        this.setState({ subscriber });
    }

    render() {
        const { isSpinning, subscriber: { name, unique_id }, adCheckboxOptions, jsCheckboxOptions, isAdShow, isJsShow, adChecked, jsChecked, channels } = this.state;
        const { getFieldDecorator } = this.props.form;
        console.log(this.state, this.props);
        return (
            <Content>
                <Spin spinning={isSpinning}>
                    <Card style={styleCard}>
                        <Form
                            style={styleForm}
                            onSubmit={this.handleSubmit}
                        >
                            <Button onClick={() => this.props.history.goBack()} icon={`rollback`} style={{ margin: '0 0 0 -60px' }}>Back</Button>
                            <FormItem
                                {...formItemLayout}
                                wrapperCol={{ xs: { span: 16 }, sm: { span: 8 } }}
                                label="包含类型"
                            >
                                {getFieldDecorator('keyword')(
                                    <div className="check-keyword">
                                        <Checkbox value="isAdShow" onChange={this.onMonitorCheckboxChange}>Google关键字</Checkbox>
                                        {
                                            isAdShow ? 
                                                <CheckboxGroup className="keyword-detail" options={adCheckboxOptions} value={adChecked} onChange={this.onKeywordCheckboxChange.bind(this, 'adChecked')} />
                                            : null
                                        }

                                        <Checkbox value="isJsShow" onChange={this.onMonitorCheckboxChange}>JS监测</Checkbox>
                                        {
                                            isJsShow ? 
                                                <CheckboxGroup className="keyword-detail" options={jsCheckboxOptions} value={jsChecked} onChange={this.onKeywordCheckboxChange.bind(this, 'jsChecked')} />
                                            : null
                                        }
                                    </div>
                                )}
                            </FormItem>

                            <FormItem
                                {...formItemLayout}
                                style={{ marginBottom: '10px' }}
                                wrapperCol={{ xs: { span: 16 }, sm: { span: 4 } }}
                                label="消息接收人"
                            >
                                {
                                    getFieldDecorator('subscriber_name', {
                                        rules: [{ required: true, message: '请输入RTX账号（拼音）!' }],
                                        initialValue: name
                                    })(
                                        <Input onChange={this.handleSubscriber.bind(this, 'name')} placeholder="请输入RTX账号（拼音）..." />
                                        )
                                }
                            </FormItem>

                            <FormItem
                                {...formItemLayout}
                                wrapperCol={{ xs: { span: 16 }, sm: { span: 4 } }}
                                label={`接收入ID`}
                            >
                                {
                                    getFieldDecorator('subscriber_id', {
                                        rules: [{ required: true, message: '请输入RTX号码!' }],
                                        initialValue: unique_id
                                    })(
                                        <Input onChange={this.handleSubscriber.bind(this, 'unique_id')} placeholder="请输入RTX号码..." />
                                        )
                                }
                            </FormItem>

                            <FormItem
                                {...formItemLayout} 
                                wrapperCol={{ xs: { span: 16 }, sm: { span: 4 } }}
                                label="通知渠道"
                            >
                                {getFieldDecorator('channels', {
                                    initialValue: channels,
                                    rules: [{ required: true, message: 'Checking the channel!' }],
                                })(
                                    <CheckboxGroup className="reset-checkbox" options={checkboxChannelOptions}  onChange={this.onChannelCheckboxChange} />
                                 )}
                            </FormItem>

                            <FormItem {...tailFormItemLayout}
                                style={{ marginTop: 32 }}>

                                <Button type="primary" htmlType="submit">
                                    提交
                                </Button>
                            </FormItem>
                        </Form>
                    </Card>
                </Spin>
            </Content>
        )
    }
}

export default Form.create()(Setting);