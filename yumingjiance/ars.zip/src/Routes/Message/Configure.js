import React, { Component } from 'react';
import { Layout, Input, Card, Button, Table, Divider, message, Modal } from 'antd';
import { Link } from 'react-router-dom';
import './Configure.css';
import * as Utils from '../../utils/utils';
import { socketConnect } from 'socket.io-react';
import axios from "axios";
const Search = Input.Search;
const { Content } = Layout;
const { confirm } = Modal;
const pageSize = 6;

const styleCard = {
    width: '60%',
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

class Configure extends Component {
    constructor(props) {
        super(props);

        this.columns = [{
            title: '订阅人',
            dataIndex: 'subscriber',
            key: 'subscriber',
            width: '12%',
            render: subscriber => <span>{subscriber.name}</span>,
        }, {
            title: '订阅事件',
            dataIndex: 'subDetail',
            key: 'subDetail',
            width: '40%',
            className: 'sub-detail',
            render: ({ keyword, website }) => <div> {keyword.reduce((a, b) => a + b.name + '、', 'Google广告词监测: (  ').slice(0, -1) + '  )'} { website.length > 0 ? <span> <Divider /> {website.reduce((a, b) => a + b.name + '、', 'JS监测结果: (  ').slice(0, -1) + '  )'}</span> : null } </div>
        }, {
            title: '消息渠道',
            dataIndex: 'channels',
            key: 'channels',
            width: '20%',
            render: channels => channels.reduce((a, b) => a + b + ' ', '').slice(0, -1)
        },{
            title: '操作',
            key: 'action',
            width: '20%',
            render: (text, record) => (
                <span>
                    <Link to={{ pathname: '/message/setting', state: record }}>编辑</Link>
                    <Divider type="vertical" />
                    <a onClick={this.handleDelClick} data-id={record.key} >删除</a>
                </span>
            ),
        }];

        this.rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                const { tableData } = this.state;
                const isInTableData = it => tableData.some(it2 => it2.key === it);
                selectedRowKeys = selectedRowKeys.filter(isInTableData);
                this.setState({ selectedRowKeys });
            }
        };
        this.pagination = {
            pageSize: pageSize,
            onChange: this.handlePaginationChange
        } 

    }
    
    state = {
        tableData: [],
        tableLoading: true,
        selectedRowKeys: [],
        formSelector: {
            keyword: ''
        }
    }


    handlePaginationChange = (page, pageSize) => {
        this.getListData(page);
    }

    componentDidMount = () => {
        this.getListData();
    }

    getListData = async (page = 1) => {
        const { formSelector } = this.state;
        for (let k in formSelector) {
            if (formSelector.hasOwnProperty(k)) {
                if (formSelector[k].length === 0) delete formSelector[k];
            }
        }
        this.setState({ tableLoading: true });
        const res = await axios.post('', Utils.json2PostData({ actionid: "1021", noat: "true", "pageindex": page, "pagesize": pageSize, ...formSelector }));
        const data = !Utils.isObject(res.data) ? JSON.parse(res.data) : res.data;
        const result = data.data.resultMessagePushs;
        if (data.code === 1 && parseInt(result.wholecount, 10) > 0) {
            const resData = Utils.deepObj2array(result.resultMessagePush, 'keyword', 'website');
            console.log(data, 'res------');
            const tableData = resData.reduce((ori, it) => {
                const subscriber = JSON.parse(it.push_person);
                const channels = JSON.parse(it.push_type);
                const key = it.id;
                const id = it.id;
                const subDetail = {
                    keyword: it.keyword ? it.keyword : [],
                    website: it.website ? it.website : []
                }
                return [...ori, {id, key, subscriber, channels, subDetail}];
            }, []);
            console.log(tableData, 'tableData---------');
            this.pagination.total = parseInt(result.wholecount, 10);
            this.pagination.current = parseInt(result.pageindex, 10);    
            // return;
            const tableLoading = false;
            this.setState({ tableData, tableLoading });
        } else {
            const tableLoading = false;
            const tableData = [];
            this.pagination.total = 0;            
            this.setState({ tableData, tableLoading });
        }
    }


    handleDelClick = e => {
        const { selectedRowKeys } = this.state;
        const dataId = e.target.getAttribute('data-id');
        const id = dataId ? dataId : selectedRowKeys;
        confirm({
            title: '注意',
            content: '确定删除',
            okText: '确认',
            cancelText: '取消',
            onOk: async () => {
                const res = await this.deleteDataById(id);
                const { history } = this.props;
                if (res.data.code === 1) {
                    message.success(res.data.msg, 1, () => {
                        this.setState({ tableLoading: true });
                        const arrId = Array.isArray(id) ? id : [id];
                        const tableData = this.state.tableData.filter(it => arrId.indexOf(it.key) === -1);
                        this.setState({ tableData, selectedRowKeys: [] }, () => {
                            this.setState({ tableLoading: false });
                        });
                        // history.go(0);
                    })
                } else {
                    message.error(res.data.msg, () => {
                        history.replace(history.location.pathname, null);
                    });
                }
            },
            onCancel() { }
        })

    }

    /**
     * 删除多条或单条数据
     * @param { array | string } id 单条string多条array
     * @return { abject } res 返回请求回来数据
     * @memberof Configure
     */
    deleteDataById = async id => {
        const hide = message.loading('删除中...');
        id = Array.isArray(id) ? id : [id];
        const makeObjId = it => ({id: it});
        const postData = { actionid: "3021", noat: "true", id: id.map(makeObjId) };
        try {
            this.props.socket.emit('client', { actionId: 3, data: id }, async (data) => {
                await Utils.timeout(500);
                if (data.code === 100) this.props.openNotification('服务器配置已更新');
            });
            const res = await axios.post('', Utils.json2PostData(postData));
            hide();
            await Utils.timeout(800);
            return res;
        } catch (err) {
            hide();
            message.error(err.toString(), 3);
        }
    }

    /**
     * 更新state然后请求数据
     */
    updateStateThenSearch = (name, value) => {
        console.log(name, value);
        const { formSelector } = this.state;
        const param = { [name]: value };
        this.setState({ formSelector: { ...formSelector, ...param } }, () => {
            this.getListData();
        });
    }
    /**
     * 搜索操作
     */
    handleKeywordSearch = value => this.updateStateThenSearch('keyword', value);

    render() {
        const { tableData, tableLoading, selectedRowKeys } = this.state;
        return (
            <Content>
                <Card style={styleCard}>
                    <Link to="/message/setting"><Button icon={`plus`} style={{ width: '100%', marginTop: '20px' }} size="large"></Button></Link>

                    <Button type="danger" onClick={this.handleDelClick} disabled={selectedRowKeys.length <= 1} style={{ margin: '25px 0 -15px 0' }}>删除</Button>

                    <Table pagination={this.pagination} rowSelection={this.rowSelection} loading={tableLoading} style={{ marginTop: '30px', background: '#fff' }} columns={this.columns} dataSource={tableData} />
                </Card>
            </Content>
        )
    }
}


export default socketConnect(Configure);