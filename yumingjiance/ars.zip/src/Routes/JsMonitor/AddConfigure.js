import React, { Component } from 'react';
import {
    Form, Icon, Input, Button, Card, TimePicker, Layout, message, Spin, Divider
} from 'antd';
import './AddConfigure.css';
import moment from 'moment';
import * as Utils from '../../utils/utils';
import isEqual from 'lodash.isequal';
import axios from 'axios';
import clone from 'clone';
import { socketConnect } from 'socket.io-react';
const { Content } = Layout;
const FormItem = Form.Item;

const iconStyle = {color: 'red', cursor: 'pointer', position: 'absolute', right: 0, marginRight: '-30px'};
const addBtnStyle = { margin: '0 -160px 0 90px' };
const defaultTimeObj = { value: '00:00:00' };

const formItemLayout = {
    labelCol: {
        xs: { span: 4 },
        sm: { span: 4 },
    },
    wrapperCol: {
        xs: { span: 8 },
        sm: { span: 8 },
    },
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 16,
            offset: 8,
        },
    },
};

const styleBtn = {
    position: 'absolute',
    marginLeft: '10px',
    marginRight: '-80px',
    top: '5px',
    right: '0'
}

const styleCard = {
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

const styleForm = {
    margin: '0 auto',
    marginTop: 8,
    width:'80%',
    background: '#fff',
    padding: '20px 0 20px 80px'
}
const configs = window.baseConfigs;
class AddConfigure extends Component{
    state = {
        keyword: '',
        isEdit: false,
        isSpinning: true,
        id: '',
        name: '',
        url: '',
        pages: [],
        execTimes: [ defaultTimeObj ]
    };
    
    componentDidMount = () => {
        const { history } = this.props;
        const { state } = history.location;
        if(Utils.isObject(state)){
            const name = state.name;
            const url = state.url;
            const id = state.id;
            const execTimes = state.execTimes.map(it => ({value: it.time}));
            const isEdit = true;
            const pages = Array.isArray(state.pages) ? state.pages : [];
            this.setState({ name, url, execTimes, isEdit, pages });
        }
        const isSpinning = false;
        this.setState({ isSpinning });
    }
    
    addTimeSelecter = e => {
        let { execTimes } = this.state;
        execTimes = [...execTimes, defaultTimeObj];
        this.setState({execTimes});    
    }

    delTimeSelecter = e => {
        let { execTimes } = this.state;
        if (execTimes.length > 1) {
            execTimes.splice(-1, 1);
            this.setState({execTimes});    
        }
    }

    addItem = (e, type, id) => {
        console.log(type, 'type-----------', this)
        switch(type){
            case 1:        // 添加page
                this.addPage(id);
                break;
            case 2: 
                this.addTest(id);
                break;
            case 3:
                this.addParam(id);
                break;
            default: 
                break;
        }
    }
    
    addPage(id) {
        const { pages } = this.state;
        const page = { "webSiteId": id, "url": '', "tests": [{ "url": '', "params": [{ "k": "", "v": "" }], "onload": true, "frequency": 2000 }] };
        pages.push(page);
        this.setState({pages});
    }

    addTest(key) {
        const { tests, id } = this.state.pages[key];
        const test = { "testPagesId": id, "url": '', "params": [{ "k": "", "v": "" }], "onload": true, "frequency": 2000 };
        tests.push(test);
        let pages = clone(this.state.pages);
        pages[key].tests = tests;
        this.setState({pages});
    }

    addParam(key) {
        let pages = clone(this.state.pages);
        const keys = key.split("-");
        let {params, id} = pages[keys[0]].tests[keys[1]];
        params = [ ...params, { "testsId": id, "k":"", "v":"" } ];
        pages[keys[0]].tests[keys[1]].params = params;
        this.setState({ pages });
    }

    handleTestUrlBlur = (e, key) => {
        const keys = key.split("-");
        const pages = clone(this.state.pages);
        const url = e.target.value;
        const resKV = Utils.paramsStringToKV(Utils.trim(url).split('?')[1]);
        pages[keys[0]].tests[keys[1]].params = resKV;
        this.setState({ pages });
    }

    handleDeleteClick = (key) => {
        const keys = key.split("-");
        console.log(keys);
        const pages = clone(this.state.pages);        
        switch (keys.length) {
            case 1:
                pages.splice(keys[0], 1);                
                break;
            case 2: 
                pages[keys[0]].tests.splice(keys[1], 2);
                break;
            case 3: 
                pages[key[0]].tests[keys[1]].params.splice(keys[2], 1);
                pages[keys[0]].tests[keys[1]].name = pages[keys[0]].tests[keys[1]].name.split('?')[0] + Utils.KVToParamsString(pages[keys[0]].tests[keys[1]].params);
                break;
            default:
                break;
        }
        this.setState({ pages });
    }

    handleTimeOnChange = (index, time, timeString) => {
        let {execTimes} = this.state;
        execTimes[index] = { value: time };
        this.setState({ execTimes });
    }
    handleSubmit = e => {
        e.preventDefault();
        let { isEdit, pages } = this.state;
        const { history, socket } = this.props;
        this.props.form.validateFields( async(err, values) => {
            if (!err) {
                console.log('Received values of form: ', values);
                const postData = isEdit ? { actionid: "4", execTimes: [], pages: pages } : { actionid: "1", execTimes: [], pages: pages};
                for (let k in values) {
                    console.log(k, 'k---------------')
                    if (values.hasOwnProperty(k)) {
                        let el = values[k];
                        let index;
                        switch (true) {
                            case k.startsWith('time-picker-'):
                                postData['execTimes'].push({ time: el.format('HH:mm:ss')});
                                break;
                            case k.startsWith('page'):
                                index = k.split("page-")[1];
                                postData['pages'][index] = { ...postData['pages'][index], ...{ url: el } };
                                break;
                            case k.startsWith('test_url'):
                                index = k.replace('test_url-', "").split("-");
                                postData['pages'][index[0]]['tests'][index[1]]['url'] = el;
                                break;
                            case k.startsWith('params-k'):
                                index = k.replace('params-k-', "").split("-");
                                postData['pages'][index[0]]['tests'][index[1]]['params'][index[2]]['k'] = el;
                                break;
                            case k.startsWith('params-v'):
                                index = k.replace('params-v-', "").split("-");
                                postData['pages'][index[0]]['tests'][index[1]]['params'][index[2]]['v'] = el;
                                break;
                            case k !== 'key':
                                postData[k] = el;
                                break;                         
                            default:
                                break;
                        }
                    }
                }
                console.log(postData, 'postData-----------')
                if( isEdit ){
                    postData.id = history.location.state.id;    // 编辑状态提交数据带入id
                }
                const actionid = isEdit ? 4 : 1;
                this.setState({ isSpinning: true });
                const res = await axios.post('', Utils.json2PostData({ "actionid": actionid, "website": postData })); 
                this.setState({ isSpinning: false }, async() => {
                    await Utils.timeout(500);
                    if (res.data.code === 1) {
                        message.success(res.data.msg, () => history.push('/js-monitor/configure', {})); 
                        const website =  isEdit ? res.data.data.Action.website : res.data.data.webScriptTest.website;
                        const sendData = Utils.deepObj2array(website, 'pages', 'execTimes', 'tests', 'params')[0];
                        const emitData = isEdit ? { actionId: 2, data: sendData } : { actionId: 1, data: sendData };
                        console.log(isEdit, emitData);
                        socket.emit('client:jsmonitor', emitData, async (data) => {
                            await Utils.timeout(500);
                            if( data.code === 100 ) this.props.openNotification('服务器配置已更新');
                        });
                    } else {
                        message.error(res.data.msg)
                    }       
                });                
            } else {
                const k = Object.keys(err)[0];
                message.error(err[k].errors[0].message);
            }
        });
    }
    render(){
        const { isSpinning, name, url, pages, execTimes, id } = this.state;
        const { getFieldDecorator } = this.props.form;
        const config = {
            rules: [{ type: 'object', required: true, message: '请选择时间!' }],
        };
        console.log('render---------');
        return (
            <Content>
                <Spin spinning={isSpinning}>                      
                    <Card style={styleCard}>
                        <Form
                            style={styleForm}
                            onSubmit={this.handleSubmit}
                        >
                            <Button onClick={() => this.props.history.goBack()} icon={`rollback`} style={{ margin: '0 0 0 -60px' }}>Back</Button>
                            <FormItem
                                {...formItemLayout}
                                label="Title"
                            >
                                {getFieldDecorator('name', {
                                    initialValue: name,
                                    rules: [{ required: true, message: 'Typing domain name!' }],
                                })(
                                    <Input placeholder="Typing domain name..." />
                                    )}
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="URL"
                            >
                                {getFieldDecorator('url', {
                                    initialValue: url,
                                    rules: [{ required: true, message: 'Typing domain url!' }],
                                })(
                                    <Input placeholder="Typing domain url..." />
                                    )}

                                <Button type="dashed" onClick={e => this.addItem(e, 1, id)} icon="plus" style={{...styleBtn, ...addBtnStyle}} >添加页面</Button>
                            </FormItem>
                            
                            <FormItem
                                {...formItemLayout}
                                wrapperCol={{ xs: { span: 16 }, sm: { span: 4 } }}
                                label="执行时间"
                            >
                                {
                                    execTimes.map((it, i) => {
                                        return getFieldDecorator(`time-picker-${i}`, { ...config, ...{ initialValue: moment(it.value, 'HH:mm:ss') } })(
                                            <TimePicker key={`${i}`} onChange={this.handleTimeOnChange.bind(this, i)} data-index={i} />
                                        )
                                    })
                                }

                                <Button type="dashed" shape="circle" onClick={this.addTimeSelecter} icon="plus" style={styleBtn} ></Button>
                                <Button type="dashed" shape="circle" onClick={this.delTimeSelecter} icon="minus" style={{ ...styleBtn, ...{ margin: '0 -130px 0 90px' } }} className="handle-button" ></Button>
                            </FormItem>
                            <Pages {...this.props} {...this} getFieldDecorator={getFieldDecorator} pages={pages || []} />

                            <FormItem {...tailFormItemLayout}
                                style={{ marginTop: 32 }}>
                                                    
                                <Button type="primary" htmlType="submit">
                                    提交
                                </Button>
                            </FormItem>
                        </Form>
                    </Card>
                </Spin>
            </Content>
        )
    }
}
export default socketConnect(Form.create()(AddConfigure))


const Pages = ({getFieldDecorator, pages, addItem, ...props}) => pages.map((it, i) => 
    <div key={it.key || `${i}`}>
        <Divider />
        <FormItem
            {...formItemLayout}
            label="Page"
        >
            <Icon type="close-circle-o" onClick={() => props.handleDeleteClick(`${i}`)} style={iconStyle} />
        
            {getFieldDecorator(`page-${i}`, {
                initialValue: it.name,
                rules: [{ required: true, message: 'Typing domain\'s page url!' }],
            })(
                <Input placeholder="Typing domain's page url..." />
                )}
            <Button type="dashed" onClick={e => addItem(e, 2, i)} icon="plus" style={{ ...styleBtn, ...addBtnStyle }} >添加测试</Button>
        </FormItem>

        <Tests {...it} {...props} tests={it.tests || []} index={i} getFieldDecorator={getFieldDecorator} addItem={addItem} />
    </div>
)

const Tests = ({ tests, getFieldDecorator, addItem, index, ...props }) => tests.map((it, i) =>
    <div key={it.key || `${i}`}>
        <FormItem
            {...formItemLayout}
            label="Test url"
        >
            <Icon type="close-circle-o" style={iconStyle} onClick={() => props.handleDeleteClick(`${index}-${i}`)} />        
            {getFieldDecorator(`test_url-${index}-${i}`, {
                initialValue: it.name,
                rules: [{ required: true, message: 'Typing url that will be test!' }],
            })(
                <Input placeholder="Typing url that will be test..." onBlur={(e) => props.handleTestUrlBlur(e, `${index}-${i}`)} />
                )}
            
            <Button type="dashed" onClick={e => addItem(e, 3, `${index}-${i}`)} icon="plus" style={{ ...styleBtn, ...addBtnStyle }} >添加参数</Button>
        </FormItem>
        <Params {...it} {...props} index={`${index}-${i}`} params={it.params || []} getFieldDecorator={getFieldDecorator} />
        <Divider dashed />
    </div>
)

const Params = ({ params, getFieldDecorator, index, ...props }) => params.map((it, i) => 
    <div key={it.key || `${i}`}>
        <FormItem
            {...formItemLayout}
            label="Params"
        >
            <Icon type="close-circle-o" style={iconStyle} onClick={() => props.handleDeleteClick(`${index}-${i}`)} />
            {getFieldDecorator(`params-k-${index}-${i}`, {
                initialValue: it.k,
                rules: [{ required: true, message: 'Typing the key of Params Object!' }],
            })(
                <Input placeholder="Typing the key of Params Object..." />
                )}
        </FormItem>

        <FormItem
            {...formItemLayout}
            label=" "
        >
            {getFieldDecorator(`params-v-${index}-${i}`, {
                initialValue: it.v,
                rules: [{ required: true, message: 'Typing the value of Params Object!' }],
            })(
                <Input placeholder="Typing the value of Params Object..." />
                )}
        </FormItem>
    </div>
)