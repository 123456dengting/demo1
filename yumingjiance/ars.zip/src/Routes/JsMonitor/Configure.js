import React, { Component } from 'react';
import { Layout, Input, Card, Button, Table, Divider, message, Modal, Tooltip } from 'antd';
import { Link } from 'react-router-dom';
import './Configure.css';
import * as Utils from '../../utils/utils'; 
import { socketConnect } from 'socket.io-react';
import axios from "axios";
const Search = Input.Search;
const { Content } = Layout;
const { confirm } = Modal;
const configs = window.baseConfigs;
const styleCard = {
    width: '80%',
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

class Configure extends Component {
    constructor(props){
        super(props);

        this.columns = [{
            title: 'Title',
            dataIndex: 'name',
            key: 'name',
            width: '40%',
            render: text => text.length > 60 ? <Tooltip title={text}>
                        <span>{text.length > 0 ? `${text.substr(0, 60)}...` : ''}</span>
                    </Tooltip> : <span>{text}</span>,
        }, {
            title: 'URL',
            dataIndex: 'url',
            key: 'url',
            width: '15%'
        }, {
            title: '定时任务',
            dataIndex: 'strExecTimes',
            key: 'strExecTimes',
            width: '10%'
        },{
            title: '操作',
            key: 'action',
            dataIndex: 'action',
            width: '15%',
        }];

        this.rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                const { tableData } = this.state;
                const isInTableData = it => tableData.some(it2 => it2.key === it);
                selectedRowKeys = selectedRowKeys.filter(isInTableData);
                this.setState({selectedRowKeys});
            }
        };
    }

    state = {
        tableData: [],
        tableLoading: true,
        selectedRowKeys: []
    }

    componentDidMount = () => {
        this.getListData();
    }
    
    getListData = async () => {
        try{
            const res = await axios.post('', Utils.json2PostData({ actionid: 2, id: -1 }));
            console.log(res.data);
            const { website } = res.data.data.webScriptTest;
            const resData = Utils.deepObj2array(website, 'pages', 'execTimes', 'tests', 'params');
            console.log(resData,'resData-----')
            if (res.data.code === 1) {
                const tableLoading = false;
                const tableData = resData.map(it => {
                    /*  ------------- temp --------------  */
                    // it.execTimes = [{ time: '00:00:00' }, { time: '15:22:33' }]; 
                    it.strExecTimes = it.execTimes.reduce((a, b) => a + b.time + '、', '').slice(0, -1);
                    /*  ------------- temp --------------  */
                    it['key'] = it.id;
                    it.action = (
                        <span>
                            <Button size="small" onClick={this.handleRunNow} data-id={it.key} type="primary">执行</Button>
                            <Divider type="vertical" />
                            <Link to={{ pathname: '/js-monitor/add-configure', state: {...it, ...{action: ''}} }}><Button size="small">编辑</Button></Link>
                            <Divider type="vertical" />
                            <Button size="small" type="danger" onClick={this.handleDelClick} data-id={it.key} >删除</Button>
                        </span>
                    )
                    it.children = Array.isArray(it.pages) ? it.pages.map(it2 => {
                        it2.name = it2.url;
                        it2.url = '';
                        it2.key = `${it.id}-${it2.id}`;
                        // console.log(it2.tests,'it.pages------')
                        it2.children = Array.isArray(it2.tests) ? it2.tests.map(it3 => {
                            it3.name = it3.url;
                            it3.url = '';
                            it3.key = `${it.id}-${it2.id}-${it3.id}`;
                            it3.children = it3.params ? [{ name: it3.params.reduce((a, it4) => `${a} ${it4.k}: ${it4.v}, `, '{').slice(0, -1) + '}', key: `${it.id}-${it2.id}-${it3.id}-0`}] : [];
                            return it3;
                        }) : [];
                        return it2;
                    }) : [];
                    return it;
                });
                this.setState({ tableData, tableLoading });
            }else{
                const tableLoading = false;
                this.setState({ tableLoading });            
            }
        }catch(err){
            console.error(err);
            message.error('net::ERR_CONNECTION_REFUSED:Please check', 4000)      
        }

    }
    

    handleGotoEditor = item => {
        this.props.history.pushState(item, '/js-monitor/add-configure');
    }
    
    handleDelClick = e => {
        const { selectedRowKeys } = this.state;
        const dataId = e.target.getAttribute('data-id')
        const id = dataId ? dataId : selectedRowKeys;
        confirm({
            title: '注意',
            content: '确定删除',
            okText: '确认',
            cancelText: '取消',
            onOk: async() => {
                const res = await this.deleteDataById(id);
                const { history } = this.props;
                if (res.data.code === 1) {
                    message.success(res.data.msg, 1, () => {
                        this.setState({ tableLoading: true });
                        const arrId = Array.isArray(id) ? id : [id];
                        const tableData = this.state.tableData.filter(it => arrId.indexOf(it.key) === -1 );
                        this.setState({ tableData, selectedRowKeys: [] }, () => {
                            this.setState({ tableLoading: false});
                        });
                    })
                } else {
                    message.error(res.data.msg, () => {
                        history.replace(history.location.pathname, null);
                    });
                }
            },
            onCancel() {}
        })

    }
    /**
     * 立即运行操作
     * @description 通过socket发送命令操作服务端立即运行指定任务
     * @memberof Configure
     */
    handleRunNow = async e => {
        const { tableData } = this.state;
        const { socket } = this.props;
        const dataId = e.target.getAttribute('data-id');
        const runData = tableData.find(it => it.id === dataId);
        if ('user' in runData) delete runData.user;
        if ('key' in runData) delete runData.key;
        let isRecieved = false;
        socket.emit('client:jsmonitor', { actionId: 4, data: runData }, async (data) => {
            isRecieved = true;
            await Utils.timeout(500);
            if( data.code === 100 ) this.props.openNotification('服务器接收命令成功');
        });
        message.success('命令已发送');
        await Utils.timeout(3000);
        if( !isRecieved ) message.error('服务器接收命令失败，请重试');
    }

    /**
     * 删除多条或单条数据
     * @param { array | string } id 单条string多条array
     * @return { abject } res 返回请求回来数据
     * @memberof Configure
     */
    deleteDataById = async id => {
        const hide = message.loading('删除中...');
        const postData = JSON.stringify({ actionid: "3", id: id });
        try {
            this.props.socket.emit('client:jsmonitor', { actionId: 3, data: id }, async (data) => {
                await Utils.timeout(500);
                if (data.code === 100) this.props.openNotification('服务器配置已更新');
            });
            const res = await axios.post('', Utils.json2FormData({json: postData}));
            hide();    
            await Utils.timeout(800);   
            return res;
        } catch (err) {
            hide();
            message.error(err.toString(), 3);
        }

    }

    
    render() {
        const { tableData, tableLoading } = this.state;
        return (
            <Content>
                <Card style={styleCard}>
                    <Search
                        placeholder="请输入搜索内容"
                        onSearch={value => console.log(value)}
                        style={{ width: 300 }}
                        size="large"
                        />
                    <Link to="/js-monitor/add-configure"><Button icon={`plus`} style={{ width: '100%', marginTop: '20px' }} size="large"></Button></Link>

                    {/* <Button type="danger" onClick={this.handleDelClick} disabled={selectedRowKeys.length <= 1} style={{ margin: '25px 0 -15px 0' }}>删除</Button> */}

                    <Table loading={tableLoading} style={{ marginTop: '30px', background: '#fff' }} columns={this.columns} dataSource={tableData} />
                </Card>
            </Content>
        )
    }
}


export default socketConnect(Configure);