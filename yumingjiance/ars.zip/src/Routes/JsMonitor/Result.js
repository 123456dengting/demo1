import React, { Component } from 'react';
import { Layout, Input, Form, Card, Table, DatePicker, Select, message, Modal, Timeline, Icon, Tooltip, Badge, Dropdown, Menu, Spin } from 'antd';
import axios from 'axios';
import * as Utils from '../../utils/utils';
import 'prismjs/themes/prism-okaidia.css';
import Prism from 'prismjs';
import { js_beautify as beautify } from "js-beautify";
import './Result.css';
const Option = Select.Option;
const Search = Input.Search;
const { Content } = Layout;
const FormItem = Form.Item;
const { RangePicker } = DatePicker;
const TimeItem = Timeline.Item;
const styleCard = {
    width: '75%',
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

const pageSize = 10;
const FORMAT = 'YYYY-MM-DD HH:mm:ss';
const configs = window.baseConfigs;
// 选择框配置数据
class Result extends Component {
    constructor(props) {
        super(props);
        this.pagination = {
            pageSize: pageSize,
            onChange: this.handlePaginationChange
        }

        this.columns = [{
            title: 'Title',
            dataIndex: 'name',
            key: 'name',
            width: '10%',
            render: text => <span>{text}</span>,
        }, {
            title: '监测页面',
            dataIndex: 'url',
            key: 'url',
            width: '30%',
            render: (text, record) => <span>{text.length > 80 ? <Tooltip title={text}>`${text.substr(0, 80)}...`</Tooltip> : text}</span>
        }, {
            title: '运行时间',
            dataIndex: 'date',
            key: 'date',
            width: '15%',
            render: text => Utils.moment('Y-M-D h:m:s', parseInt(text, 10))
        }, {
            title: '检测结果',
            dataIndex: 'gtm',
            key: 'gtm',
            width: '45%',
            render: results => Array.isArray(results) ? results.map(it => <span className="result-text"> {parseInt(it.gtmResult, 10) === 1 ? <Icon type="check-circle" style={{ color: '#52c41a' }} /> : <Icon type="close-circle" style={{ color: '#f5222d'}} />} {it.gtmUrl.length > 60 ? <Tooltip title={it.gtmUrl}>{`${it.gtmUrl.substr(0, 60)}...`}</Tooltip> : it.gtmUrl}</span>) : ''
        }];
        this.expandedRowRender = (data) => {
            const columns = [
                { title: 'ID', dataIndex: '_id', key: 'id', width: '5%' },
                { title: '级别', dataIndex: 'level', key: 'level', width: '5%' },
                { title: '上级ID', dataIndex: 'pid', key: 'pid', width: '5%' },
                { 
                    title: '是否GTM启动代码',
                    dataIndex: 'gtmStart',
                    key: 'gtmStart',
                    width: '5%',
                    render:  text => parseInt(text, 10) === 1 ? `是` : `否`},
                { 
                    title: '是否GTM载入',
                    dataIndex: 'gtmRef',
                    key: 'gtmRef', 
                    width: '5%', 
                    render: text => parseInt(text, 10) === 1 ? `是` : `否`
                },
                { title: 'JS-URL', dataIndex: 'url', key: 'url', width: '25%' },
                {
                    title: 'JS内容摘要',
                    dataIndex: 'keyWord',
                    key: 'keyWord',
                    width: '25%',
                    render: (text, record) => <span>{`${text.substr(0, 80)}...`}<a onClick={() => this.handleSeeMore(record.codePath)} >more</a></span>
                }
            ];
            data.res = data.res.map(it => { it.key = it.id; return it; });
            return (
                <Table
                    columns={columns}
                    dataSource={data.res}
                    pagination={false}
                />
            );
        };
    }
    state = {
        formSelector: {
            webid: ''
        },
        tableLoading: true,
        tableData: [],
        websites: [],     // 选择框基础数据
        fullCode: '',  
        total: 0,
        modalVisible: false
    }

    /**
     * 组件绑定执行异步请求数据
     */
    componentDidMount = () => {
        this.getListData();
        this.getBasicalData();
    }
    /**
     * 更新state然后请求数据
     */
    updateStateThenSearch = (name, value) => {
        const { formSelector } = this.state;
        const param = { [name]: value };
        this.setState({ formSelector: { ...formSelector, ...param } }, () => {
            this.getListData();
        });
    }

    /**
     * 选择国家操作
     */
    handleCountryChange = value => this.updateStateThenSearch('country', value);

    /**
     * 搜索操作
     */
    handleKeywordSearch = value => this.updateStateThenSearch('keyword', value);

    /**
     * 选择站点操作
     */
    handleDomainChange = value => this.updateStateThenSearch('webid', value);

    /**
     * 时间选择操作
     */
    handleRangeOk = value => {
        const { formSelector } = this.state;
        const startTime = value[0].format(FORMAT);
        const endTime = value[1].format(FORMAT);
        this.setState({ formSelector: { ...formSelector, startTime, endTime } }, () => {
            this.getListData();
        });
    }

    handlePaginationChange = (page, pageSize) => {
        this.getListData(page);
    }

    /**
     * 通过条件获取ListData数据
     */
    getListData = async (page = "1") => {
        const { formSelector } = this.state;
        for (let k in formSelector) {
            if (formSelector.hasOwnProperty(k)) {
                if (formSelector[k].length === 0) delete formSelector[k];
            }
        }
        try {
            this.setState({ tableLoading: true });     // 设置loading标识
            const params = { ...{ actionid: "16", noat: "true", page: page, count: `${pageSize}` }, ...formSelector };
            const res = await axios.post('', Utils.json2PostData(params));
            if (res.data.code === 1) {
                const { pages, count, size, page } = res.data.data.testresult;

                const resData = parseInt(count, 10) > 0 ? Utils.deepObj2array(pages, 'pages', 'param', 'res', 'gtm') : [];
                console.log(resData,'resData-----')
                const tableData = resData.map(it => {
                    it['key'] = it.id;
                    return it;
                });1
                this.pagination.total = parseInt(count, 10);
                this.pagination.current = parseInt(page, 10);
                this.setState({ tableData }, () => {
                    this.setState({ tableLoading: false });
                });
            } else {        // 查询数据为空
                this.pagination.total = 0;
                this.setState({ tableData: [] }, () => {
                    this.setState({ tableLoading: false });
                });
            }
        } catch (err) {
            // message.error(err.toString(), 4, () => this.props.history.go(0));
        }
    }

    getBasicalData = async() => {
        try {
            const params = { actionid: "17", noat: "true" };
            const res = await axios.post('', Utils.json2PostData(params));
            if (res.data.code === 1) {
                const websites = res.data.data.list.website;
                this.setState({ websites });
            } else {        // 查询数据为空
                message.error(res.data.msg);
            }
        } catch (err) {
            message.error(err.toString(), 4, () => this.props.history.go(0));
        }
    }

    handleSeeMore = async (codePath) => {
        try {
            const param = { codePath: codePath };
            this.setState({modalVisible: true});
            const url = configs.IS_DEV ? 'http://127.0.0.1:3007/api' : 'http://10.40.2.68:3007/api';
            const res = await axios.get(url + '/get/code', { params: param }); 
            if(res.data.code === 0){
                this.setState({ fullCode: res.data.data});
            }else{
                message.error(res.data.msg);
            }
        } catch (err) {
            console.error(err);     
            message.error('net::ERR_CONNECTION_REFUSED:Please check');
        }
    }

    handleModalClose = () => {
        this.setState({ modalVisible: false }, () => {
            this.setState({ fullCode: '' });
        })
    }

    render() {
        const { tableLoading, tableData, websites } = this.state;
        return (
            <Content>
                <Card style={styleCard}>
                    <FormItem>
                        <Select defaultValue="All" style={{ width: 120 }} onChange={this.handleDomainChange}>
                            <Option value="">All</Option>
                            {
                                websites && websites.map(it => <Option key={it.id} value={it.id}>{it.name}</Option>)
                            }
                        </Select>
                    </FormItem>
                    <ModalCode {...this}/>
                    <Table 
                        expandedRowRender={this.expandedRowRender} 
                        loading={tableLoading} 
                        style={{ marginTop: '30px', background: '#fff' }} 
                        columns={this.columns} 
                        dataSource={tableData} 
                        pagination={this.pagination} />
                </Card>
            </Content>
        )
    }
}
const ModalCode = ({ state: { fullCode, modalVisible }, handleModalClose , ...props}) =>
{
    const html = Prism.highlight(beautify(fullCode, { indent_size: 2 }), Prism.languages.javascript);
    return <Modal
        title="Show full code"
        visible={modalVisible}
        onCancel={handleModalClose}
        width={1200}
        footer={<div><button onClick={handleModalClose} type="button" className="ant-btn ant-btn-primary"><span>OK</span></button></div>}
    >
        { 
            fullCode.length > 0 ? 
            <pre className="brush:javascript;toolbar:false language-javascript line-numbers">
                <code className="language-javascript" dangerouslySetInnerHTML={{ __html: html }} />
            </pre>
                : 
            <Spin/>              
        }
    </Modal>

}
export default Result;