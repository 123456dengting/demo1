import React, { Component } from 'react';
import { Form, Icon, Input, Button, Message, Spin } from 'antd';
import axios from 'axios';
import * as Utils from '../../utils/utils';
import './Login.css';
const FormItem = Form.Item;

class Login extends Component {
    state = {
        loading: false
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                console.log('Received values of form: ', values);
                const userName = Utils.trim(values.userName);
                const password = Utils.trim(values.password);
                this.login(userName, password);
            }
        });
    }

    login = async(userName, password) => {
        const param = {
            type: 'getToken',
            grantType: 'ars',
            userId: userName,
            password: password
        }
        this.setState({ loading: true });
        const res = await axios.get('http://10.36.3.66:9010/api/v1.0/oauth/access_token', { params: param });
        this.setState({ loading: false }); 
        await Utils.timeout(500);
        if(!res.data.success) {
            Message.error('登陆失败，请重试');
        }else{
            Utils.setUser(res.data.data);       // 保存用户信息
            Message.success('登录成功', () => {
                this.props.history.push('/ad-monitor/result', null);
            });
        }
               
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        return (
            <div className="container">
                <Form onSubmit={this.handleSubmit} className="login-form">
                    <div className="header"><h1>ARS自动化检测平台</h1></div>
                    <Spin spinning={this.state.loading} tip={`loading...`}>
                        <FormItem>
                            {getFieldDecorator('userName', {
                                rules: [{ required: true, message: 'Please input your username!' }],
                            })(
                                <Input prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />} placeholder="Username" />
                                )}
                        </FormItem>
                        <FormItem>
                            {getFieldDecorator('password', {
                                rules: [{ required: true, message: 'Please input your Password!' }],
                            })(
                                <Input prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" placeholder="Password" />
                                )}
                        </FormItem>
                        <FormItem>
                            <Button type="primary" htmlType="submit" className="login-form-button">
                                Log in
                            </Button>
                        </FormItem>
                    </Spin>
                </Form>
            </div>
        );
    }
}

export default Form.create()(Login);