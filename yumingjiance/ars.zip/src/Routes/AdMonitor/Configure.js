import React, { Component } from 'react';
import { Layout, Input, Card, Button, Table, Divider, message, Modal } from 'antd';
import { Link } from 'react-router-dom';
import './Configure.css';
import * as Utils from '../../utils/utils'; 
import { socketConnect } from 'socket.io-react';
import axios from "axios";
const Search = Input.Search;
const { Content } = Layout;
const { confirm } = Modal;

const styleCard = {
    width: '60%',
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

const devices = {
    'PC': 'PC端',
    'iPad': 'iPad',
    'mobile': '移动端'
}

class Configure extends Component {
    constructor(props){
        super(props);

        this.columns = [{
            title: '关键字',
            dataIndex: 'keyword',
            key: 'keyword',
            width: '20%',
            render: text => <span>{text}</span>,
        }, {
            title: '国家',
            dataIndex: 'country',
            key: 'country',
            width: '15%',
            render: countrys => countrys.reduce((a, b) => a + b.name + '、', '').slice(0, -1)
        }, {
            title: '运行设备',
            dataIndex: 'devices',
            key: 'devices',
            width: '20%',
            render: dvs => dvs.reduce((a, b) => a + devices[b.userAgent] + '、', '').slice(0, -1)
        }, {
            title: '定时任务',
            dataIndex: 'execTime',
            key: 'execTime',
            width: '25%',
            render: times => times.reduce((a, b) => a + b.time + '、', '').slice(0, -1)
        },{
            title: '操作',
            key: 'action',
            width: '25%',
            render: (text, record) => (
                <span>
                    <Link to={{ pathname:'/ad-monitor/add-configure', state: record }}>编辑</Link>
                    <Divider type="vertical" />
                    <a onClick={this.handleRunNow} data-id={record.key} >立即运行</a>
                    <Divider type="vertical" />                    
                    <a onClick={this.handleDelClick} data-id={record.key} >删除</a> 
                </span>
            ),
        }];

        this.rowSelection = {
            onChange: (selectedRowKeys, selectedRows) => {
                const { tableData } = this.state;
                const isInTableData = it => tableData.some(it2 => it2.key === it);
                selectedRowKeys = selectedRowKeys.filter(isInTableData);
                this.setState({selectedRowKeys});
            }
        };
    }

    state = {
        tableData: [],
        tableLoading: true,
        selectedRowKeys: [],
        formSelector: {
            keyword: ''
        }
    }

    componentDidMount = () => {
        this.getListData();  
    }
    
    getListData = async () => {
        const { formSelector } = this.state;
        for (let k in formSelector) {
            if (formSelector.hasOwnProperty(k)) {
                if (formSelector[k].length === 0) delete formSelector[k];
            }
        }
        const res = await axios.post('', Utils.json2PostData({ actionid: "7", id: "-1", ...formSelector }));
        const data = !Utils.isObject(res.data) ? JSON.parse(res.data) : res.data;
        if(data.code === 1){
            const { keyword } = data.data.autoTest;
            const resData = Utils.deepObj2array(keyword, 'country', 'execTime', 'devices');
            const tableData = resData.map(it => {
                it['key'] = it.id;
                it['user'] = '';
                return it;
            });
            const tableLoading = false;
            this.setState({ tableData, tableLoading });
        }else if(data.code === -1){
            const tableLoading = false;
            const tableData = [];
            this.setState({ tableData, tableLoading });            
        }
    }
    
    
    handleDelClick = e => {
        const { selectedRowKeys } = this.state;
        const dataId = e.target.getAttribute('data-id')
        const id = dataId ? dataId : selectedRowKeys;
        confirm({
            title: '注意',
            content: '确定删除',
            okText: '确认',
            cancelText: '取消',
            onOk: async() => {
                const res = await this.deleteDataById(id);
                const { history } = this.props;
                if (res.data.code === 1) {

                    message.success(res.data.msg, 1, () => {
                        this.setState({ tableLoading: true });
                        const arrId = Array.isArray(id) ? id : [id];
                        const tableData = this.state.tableData.filter(it => arrId.indexOf(it.key) === -1 );
                        this.setState({ tableData, selectedRowKeys: [] }, () => {
                            this.setState({ tableLoading: false});
                        });
                        // history.go(0);
                    })
                } else {
                    message.error(res.data.msg, () => {
                        history.replace(history.location.pathname, null);
                    });
                }
            },
            onCancel() {}
        })

    }
    /**
     * 立即运行操作
     * @description 通过socket发送命令操作服务端立即运行指定任务
     * @memberof Configure
     */
    handleRunNow = async e => {
        const { tableData } = this.state;
        const { socket } = this.props;
        const dataId = e.target.getAttribute('data-id');
        const runData = tableData.find(it => it.id === dataId);
        if ('user' in runData) delete runData.user;
        if ('key' in runData) delete runData.key;
        let isRecieved = false;
        socket.emit('client', { actionId: 4, data: runData }, async (data) => {
            isRecieved = true;
            await Utils.timeout(500);
            if(data.code === 100) this.props.openNotification('服务器接收命令成功');
        });
        message.success('命令已发送');
        await Utils.timeout(3000);
        if(!isRecieved) message.error('服务器接收命令失败，请重试');
    }

    /**
     * 删除多条或单条数据
     * @param { array | string } id 单条string多条array
     * @return { abject } res 返回请求回来数据
     * @memberof Configure
     */
    deleteDataById = async id => {
        const hide = message.loading('删除中...');
        const postData = Array.isArray(id) ? JSON.stringify({ actionid: "13", delete: id.map(it => ({id: `${it}`})) }) : JSON.stringify({actionid: "8", id: id, isDelete: "Y"}); 
        try {
            this.props.socket.emit('client', { actionId: 3, data: id }, async (data) => {
                await Utils.timeout(500);
                if(data.code === 100) this.props.openNotification('服务器配置已更新');
            });
            const res = await axios.post('', Utils.json2FormData({json: postData}));
            hide();    
            await Utils.timeout(800);   
            return res;
        } catch (err) {
            hide();
            message.error(err.toString(), 3);
        }
    }

    /**
     * 更新state然后请求数据
     */
    updateStateThenSearch = (name, value) => {
        console.log(name, value);
        const { formSelector } = this.state;
        const param = { [name]: value };
        this.setState({ formSelector: { ...formSelector, ...param } }, () => {
            this.getListData();
        });
    }
    /**
     * 搜索操作
     */
    handleKeywordSearch = value => this.updateStateThenSearch('keyword', value);

    render() {
        const { tableData, tableLoading, selectedRowKeys } = this.state;
        return (
            <Content>
                <Card style={styleCard}>
                    <Search
                        placeholder="请输入搜索内容"
                        onSearch={this.handleKeywordSearch}
                        style={{ width: 300 }}
                        size="large"
                        />
                    <Link to="/ad-monitor/add-configure"><Button icon={`plus`} style={{ width: '100%', marginTop: '20px' }} size="large"></Button></Link>

                    <Button type="danger" onClick={this.handleDelClick} disabled={selectedRowKeys.length <= 1} style={{ margin: '25px 0 -15px 0' }}>删除</Button>

                    <Table rowSelection={this.rowSelection} loading={tableLoading} style={{ marginTop: '30px', background: '#fff' }} columns={this.columns} dataSource={tableData} />
                </Card>
            </Content>
        )
    }
}


export default socketConnect(Configure);