import React, { Component } from 'react';
import { Layout, Input, Form, Card, Table, DatePicker, Select, message, Modal, Timeline, Icon, Tooltip } from 'antd';
import axios from 'axios';
import * as Utils from '../../utils/utils';
import qs from 'query-string';
import './Result.css';
const Option = Select.Option;
const Search = Input.Search;
const { Content } = Layout;
const FormItem = Form.Item;
const { RangePicker } = DatePicker;
const TimeItem = Timeline.Item;
const styleCard = {
    width: '95%',
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

const pageSize = 20;
const FORMAT = 'YYYY-MM-DD HH:mm:ss';
 // 选择框配置数据
const options = [
    { label: '不限', value: '' },
    { label: '美国', value: '美国' },
    { label: '加拿大', value: '加拿大' },
    { label: '英国', value: '英国' },
    { label: '澳大利亚', value: '澳大利亚' },
    { label: '法国', value: '法国' },
];

class Result extends Component {
    constructor(props){
        super(props);
        this.pagination = {
            pageSize: pageSize,
            onChange: this.handlePaginationChange
        } 

        this.columns = [{
            title: '关键字',
            dataIndex: 'keyword',
            key: 'keyword',
            width: '3%',
            render: text => <span>{text}</span>,
        }, {
            title: '广告词',
            dataIndex: 'advertisingWord',
            key: 'advertisingWord',
            width: '7%',
            render: text => <Tooltip title={text}>
                                <span>{text.length > 0 ? `${text.substr(0, 25)}...` : ''}</span>
                            </Tooltip>
        }, {
            title: '广告内容',
            dataIndex: 'advertisingContent',
            key: 'advertisingContent',
            width: '9%',
            render: text => <Tooltip title={text}>
                <span>{text.length > 0 ? `${text.substr(0, 25)}...` : ''}</span>
            </Tooltip>
        }, {
            title: '跳转网址',
            dataIndex: 'redirections',
            key: 'redirections',
            width: '9%',
            render: (redirections, record) => <p>{`${redirections[0].url.substr(0, 25)}...`}<a onClick={this.handleSeeMore} data-id={record.key} >more</a></p>,
        }, {
            title: '着陆页',
            dataIndex: 'requestUrl',
            key: 'requestUrl',
            width: '8%'
        }, {
            title: '投放国家',
            dataIndex: 'country',
            key: 'country',
            width: '2%'
        }, {
            title: '页码',
            dataIndex: 'fromPage',
            key: 'fromPage',
            width: '1%'
        },{
            title: '运行设备',
            dataIndex: 'userAgent',
            key: 'userAgent',
            width: '2%'
        }, {
            title: '来源系统',
            dataIndex: 'lkid_system',
            key: 'lkid_system',
            width: '3%'
        }, {
            title: '对应投放账户',
            dataIndex: 'lkid_user_name',
            key: 'lkid_user_name',
            width: '3%'
        }, {
            title: '用户ID',
            dataIndex: 'lkid_user_id',
            key: 'lkid_user_id',
            width: '5%'
        }, {
            title: '运行时间',
            dataIndex: 'execTime',
            key: 'execTime',
            width: '6%',
            render: text => text.replace("T", " ")
        }];
    }
    state = {
        formSelector:{
            startTime: '',
            endTime: '',
            country: '',
            keyword: ''
        },
        tableLoading: true,
        tableData: [],
        total: 0
    }
   
    /**
     * 组件绑定执行异步请求数据
     */
    componentDidMount = () =>{
        const { location: { search } } = this.props;
        const { start, end, keyword } = qs.parse(search);
        const { formSelector } = this.state;
        formSelector.startTime = start ? Utils.moment('Y-M-D h:m:s', start) : '';
        formSelector.endTime = end ? Utils.moment('Y-M-D h:m:s', end) : '';
        this.setState({ formSelector: {...formSelector, keyword} }, () => {
            console.log(this.state);
            this.getListData();
        })
    };

    /**
     * 更新state然后请求数据
     */
    updateStateThenSearch = (name, value) => {
        const { formSelector } = this.state;
        const param = {[name]: value};
        this.setState({ formSelector: { ...formSelector, ...param } }, () => {
            this.getListData();
        });
    }
    
    /**
     * 选择国家操作
     */
    handleCountryChange = value => this.updateStateThenSearch('country', value);

    /**
     * 搜索操作
     */
    handleKeywordSearch = value => this.updateStateThenSearch('keyword', value);
    
    /**
     * 时间选择操作
     */
    handleRangeOk = value => {
        const { formSelector } = this.state;
        const startTime = value[0].format(FORMAT);
        const endTime = value[1].format(FORMAT);
        console.log(startTime, endTime);
        this.setState({formSelector: {...formSelector, startTime, endTime}}, () => {
            this.getListData();
        });
    }
    
    handlePaginationChange = (page, pageSize) => {
        this.getListData(page);
    }

    /**
     * 通过条件获取ListData数据
     */
    getListData = async (page = "1") => {
        const { formSelector } = this.state;
        for (let k in formSelector) {
            if (!formSelector[k]) {
                console.log(formSelector[k]);
                delete formSelector[k];
            }
        }
        try {
            this.setState({ tableLoading: true });     // 设置loading标识
            const params = { ...{ actionid: "11", page: page, count: `${pageSize}` }, ...formSelector };
            const res = await axios.post('', Utils.json2PostData(params));
            if (res.data.code === 1 && res.data.data.root.count > 0) {
                const { root: { count, result } } = res.data.data;
                const resData = Utils.deepObj2array(result, 'redirections');
                const tableData = resData.map(it => {
                    it['lkid_user_id'] = it.lkid_user_id ? it.lkid_user_id : '';
                    it['lkid_system'] = it.lkid_system ? it.lkid_system : '';
                    it['lkid_user_name'] = it.lkid_user_name ? it.lkid_user_name : '';
                    it['key'] = it.id;
                    return it;
                });
                this.pagination.total = parseInt(count, 10);
                this.pagination.current = parseInt(page, 10);       
                this.setState({ tableData }, () => {
                    this.setState({ tableLoading: false });
                });
            }else {        // 查询数据为空
                this.pagination.total = 0;       
                this.setState({ tableData: [] }, () => {
                    this.setState({ tableLoading: false });
                });
            }
        } catch (err) {
            message.error(err.toString(), 4, () => this.props.history.go(0));
        }
    }

    handleSeeMore = e => {
        const id = e.target.getAttribute('data-id');
        const { tableData } = this.state;
        const rowData = tableData.find(it => it.id === id);
        const content = rowData.redirections.map(it => it.url.length > 0 ? <TimeItem dot={<Icon type="link" />} className="my-modal-content" key={it.id}>{it.url}</TimeItem> : null);
        Modal.info({
        title: `关键词-${rowData.keyword}-跳转路由详细`,
            content: (
                <Timeline>
                    {content}
                </Timeline>
            ),
            onOk() {},
        });
    }
    

    render() {
        const { tableLoading, tableData } = this.state;
        return (
            <Content>
                <Card style={styleCard}>
                    <FormItem>
                        <RangePicker
                            showTime={{ format: 'HH:mm:ss' }}
                            format={FORMAT}
                            placeholder={['Start Time', 'End Time']}
                            onOk={this.handleRangeOk}
                        />{`   `}
                        <Select defaultValue="不限" style={{ width: 120 }} data-name="country" onChange={this.handleCountryChange}>
                            {
                                options.map((it, i) => <Option key={`${i}`} value={it.value}>{it.label}</Option> )
                            }
                        </Select>{`   `}
                        <Search
                            placeholder="请输入搜索内容"
                            onSearch={this.handleKeywordSearch}
                            style={{ width: 300 }}
                            data-name="keyword"
                        />
                    </FormItem>
                    <Table loading={tableLoading} style={{ marginTop: '30px', background: '#fff' }} columns={this.columns} dataSource={tableData} pagination={this.pagination} />
                </Card>
            </Content>
        )
    }
}


export default Result;