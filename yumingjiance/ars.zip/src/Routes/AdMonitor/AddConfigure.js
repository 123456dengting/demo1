import React, { Component } from 'react';
import {
    Form, Input, Button, Card, TimePicker, Layout, Checkbox, message, Select, Spin
} from 'antd';
import './AddConfigure.css';
import moment from 'moment';
import * as Utils from '../../utils/utils';
import axios from 'axios';
import { socketConnect } from 'socket.io-react';
const CheckboxGroup = Checkbox.Group;
const { Content } = Layout;
const FormItem = Form.Item;
const { Option } = Select;

const defaultTimeObj = { value: '00:00:00' };

const formItemLayout = {
    labelCol: {
        xs: { span: 4 },
        sm: { span: 4 },
    },
    wrapperCol: {
        xs: { span: 16 },
        sm: { span: 16 },
    },
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 16,
            offset: 8,
        },
    },
};

const styleBtn = {
    position: 'absolute',
    marginLeft: '10px',
    marginRight: '-80px',
    top: '5px',
    right: '0'
}

const styleCard = {
    margin: '0 auto',
    background: '#f0f2f5',
    border: 0
}

const styleForm = {
    margin: '0 auto',
    marginTop: 8,
    width:'50%',
    background: '#fff',
    padding: '20px 0 20px 80px'
}

const options = [
    { label: '美国', value: '美国' },
    { label: '加拿大', value: '加拿大' },
    { label: '英国', value: '英国' },
    { label: '澳大利亚', value: '澳大利亚' },
    { label: '法国', value: '法国' },
];

const languagesOptions = [
    {
        "label": "English",
        "value": "en"
    },
    {
        "label": "Deutsch",
        "value": "de"
    },
    {
        "label": "español",
        "value": "es"
    },
    {
        "label": "français",
        "value": "fr"
    },
    {
        "label": "italiano",
        "value": "it"
    },
    {
        "label": "português (Portugal)",
        "value": "pt-PT"
    }
]

const userAgentOptions = [
    { label: 'PC端', value: 'PC' },
    { label: 'iPad', value: 'iPad' },
    { label: '移动端', value: 'mobile' }
];
const defaultCheckedList = ['美国'];
const defaultUACheckedList = ['PC'];
const defaultLanChecked = ["en"]

class AddConfigure extends Component{
    state = {
        timeSelectors: [ defaultTimeObj ],
        ctyCheckedList: defaultCheckedList,
        UACheckedList: defaultUACheckedList,
        lanChecked: defaultLanChecked,
        keyword: '',
        isEdit: false,
        isSpinning: true
    };
    
    componentDidMount = () => {
        const { history } = this.props;
        const { state } = history.location;
        if(Utils.isObject(state)){
            const timeSelectors = state.execTime.map(it => ({value: it.time}));
            const ctyCheckedList = state.country.map(it => it.name);
            const UACheckedList = state.devices.map(it => it.userAgent);
            const isEdit = true;
            const keyword = state.keyword;
            this.setState({ timeSelectors, ctyCheckedList, UACheckedList, isEdit, keyword });
        }
        const isSpinning = false;
        this.setState({ isSpinning });
    }
    
    addTimeSelecter = e => {
        let { timeSelectors } = this.state;
        timeSelectors = [...timeSelectors, defaultTimeObj];
        this.setState({timeSelectors});    
    }

    delTimeSelecter = e => {
        let { timeSelectors } = this.state;
        if (timeSelectors.length > 1) {
            timeSelectors.splice(-1, 1);
            this.setState({timeSelectors});    
        }
    }

    handleTimeOnChange = (index, time, timeString) => {
        let {timeSelectors} = this.state;
        timeSelectors[index] = { value: time };
        this.setState({ timeSelectors });
    }
    handleSubmit = e => {
        e.preventDefault();
        let { isEdit } = this.state;
        const { history, socket } = this.props;
        this.props.form.validateFields( async(err, values) => {
            if (!err) {
                console.log('Received values of form: ', values);
                const postData = isEdit ? { actionid: "8", execTime: [] } : { actionid: "6", execTime: []};
                for (let k in values) {
                    if (values.hasOwnProperty(k)) {
                        let el = values[k];
                        switch (true) {
                            case k.startsWith('time-picker-'):
                                postData['execTime'].push({ time: el.format('HH:mm:ss') });
                                break;
                            case k === 'country':
                                postData[k] = el.map(it => ({ name: it }));
                                break;
                            case k === 'devices':
                                postData[k] = el.map(it => ({ userAgent: it }));
                                break;
                            case k !== 'key':
                                postData[k] = el;
                                break;                         
                            default:
                                break;
                        }
                    }
                }
                if( isEdit ) postData.id = history.location.state.id;    // 编辑状态提交数据带入id
                this.setState({ isSpinning: true });
                const res = await axios.post('', Utils.json2FormData({ json: JSON.stringify(postData) })); 
                this.setState({ isSpinning: false }, async() => {
                    await Utils.timeout(500);
                    if (res.data.code === 1) {
                        message.success(res.data.msg, () => history.push('/ad-monitor/configure', {})); 
                        const emitData = isEdit ? { actionId: 2, data: res.data.data } : { actionId: 1, data: res.data.data };
                        socket.emit('client', emitData, async (data) => {
                            await Utils.timeout(500);
                            if( data.code === 100 ) this.props.openNotification('服务器配置已更新');
                        });
                    } else{
                        message.error(res.data.msg);
                    }       
                });                
            } else {
                const k = Object.keys(err)[0];
                message.error(err[k].errors[0].message);
            }
        });
    }
    render(){
        const { timeSelectors, ctyCheckedList, lanChecked, keyword, UACheckedList, isSpinning } = this.state;
        const { getFieldDecorator } = this.props.form;
        const config = {
            rules: [{ type: 'object', required: true, message: '请选择时间!' }],
        };
        return (
            <Content>
                <Spin spinning={isSpinning}>                      
                    <Card style={styleCard}>
                        <Form
                            style={styleForm}
                            onSubmit={this.handleSubmit}
                        >
                            <Button onClick={() => this.props.history.goBack()} icon={`rollback`} style={{ margin: '0 0 0 -60px' }}>返回</Button>
                            <FormItem
                                {...formItemLayout}
                                label="关键字"
                            >
                                {getFieldDecorator('keyword', {
                                    initialValue: keyword,
                                    rules: [{ required: true, message: '请输入关键字!' }],
                                })(
                                    <Input placeholder="请输入关键字" />
                                    )}
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="域名标识"
                            >
                                {getFieldDecorator('domainSign', {
                                    initialValue: 'rosegal',
                                    rules: [{ required: true, message: '请输入域名标识!' }],
                                })(
                                    <Select style={{ width: 125 }}>
                                        <Option value="rosegal">rosegal</Option>
                                        <Option value="dresslily">dresslily</Option>
                                        <Option value="zaful">zaful</Option>
                                        <Option value="rosewholesale">rosewholesale</Option>
                                        <Option value="sammydress">sammydress</Option>
                                        <Option value="twinkledeals">twinkledeals</Option>
                                        <Option value="trendsgal">trendsgal</Option>
                                        <Option value="gamiss">gamiss</Option>
                                    </Select>
                                    )}
                            </FormItem>
                            

                            <FormItem
                                {...formItemLayout}
                                wrapperCol= {{ xs: {span: 16 }, sm: {span: 4 } }}                    
                                label="选择时间"
                            >     
                                {
                                    timeSelectors.map((it, i) => {
                                            return getFieldDecorator(`time-picker-${i}`, { ...config, ...{ initialValue: moment(it.value, 'HH:mm:ss') }})(
                                            <TimePicker key={`${i}`} onChange={this.handleTimeOnChange.bind(this, i)} data-index={i} />
                                        )
                                    })
                                }              

    
                                <Button type="default" size="small" onClick={this.addTimeSelecter} icon="plus" style={styleBtn} ></Button>               
                                <Button type="default" size="small" onClick={this.delTimeSelecter} icon="minus" style={{...styleBtn, ...{margin: '0 -130px 0 90px'}} } className="handle-button" ></Button>               
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="选择国家"
                            >
                                {getFieldDecorator('country', {
                                    initialValue: ctyCheckedList,
                                    rules: [{ required: true, message: '请选择国家!' }],
                                })(
                                    <CheckboxGroup 
                                        options={options} 
                                        />
                                    )}
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="选择语言"
                            >
                                {getFieldDecorator('language', {
                                    initialValue: lanChecked,
                                    rules: [{ required: true, message: '请选择语言!' }],
                                })(
                                    <CheckboxGroup 
                                        options={languagesOptions} 
                                        />
                                    )}
                            </FormItem>
                            <FormItem
                                {...formItemLayout}
                                label="运行设备"
                            >
                                {getFieldDecorator('devices', {
                                    initialValue: UACheckedList,
                                    rules: [{ required: true, message: '请选择运行设备!' }],
                                })(
                                    <CheckboxGroup
                                    options={userAgentOptions}
                                    />
                                    )}
                            </FormItem>
                            <FormItem {...tailFormItemLayout}
                                style={{ marginTop: 32 }}>
                                                    
                                <Button type="primary" htmlType="submit">
                                    提交
                                </Button>
                            </FormItem>
                        </Form>
                    </Card>
                </Spin>
            </Content>
        )
    }
}
export default socketConnect(Form.create()(AddConfigure))