class Tools {

    static timeout(delay) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                try {
                    resolve(1)
                } catch (e) {
                    reject(0)
                }
            }, delay)
        })
    }
    /**
     * format string params to Json
     * 
     * @static
     * @param {string} [str=''] 
     * @returns 
     * @memberof Tools
     */
    static paramsStringToJson(str = '') {
        if (Tools.trim(str) === '') return [];
        const arrStr = str.split('&');
        return arrStr.reduce((a, b) => {
            let k = b.split('=')[0];
            let v = b.split('=')[1];
            return { ...a, ...{ [k]: v } };
        }, {});
    }
    /**
     * format string params to KV
     * 
     * @static
     * @param {string} [str=''] 
     * @returns Array
     * @memberof Tools
     */
    static paramsStringToKV(str = '') {
        if (Tools.trim(str) === '') return [];
        const arrStr = str.split('&');
        return arrStr.reduce((a, b) => {
            let k = b.split('=')[0];
            let v = b.split('=')[1];
            return [ ...a, { k:k, v:v } ];
        }, []);
    }

    static trim(str){ //删除左右两端的空格
        return str.replace(/(^\s*)|(\s*$)/g, "");
    }
    /**
     * [TimeTools description]
     * @param {[type]} timestamp  12312312312312
     * @param {[type]} formatStr Y年M月D日
     *
     * M: month 1~12
     * Y: year 2017
     * D: date 0 ~ 31
     */
    static moment(formatStr, timestamp) {
        let date = new Date(parseInt(timestamp) || new Date().getTime())
        let M = date.getMonth() + 1

        let Y = date.getFullYear()

        let D = date.getDate()

        let h = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();

        let m = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();

        let s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

        return formatStr.replace('M', M).replace('Y', Y).replace('D', D).replace('h', h).replace('m', m).replace('s', s)
    }

    static verify(type = '', str = '') {
       let reg = new RegExp();
       switch (type.toUpperCase()) {
           case 'URL':
               reg = new RegExp('(http | https |ftp | file)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]');
            //    /^((ht|f)tps?):\/\/([\w-]+(\.[\w-]+)*\/?)+(\?([\w\-\.,@?^=%&:\/~\+#]*)+)?$/
               break;
           default:
               break;
       }
       return reg.test(str);
    }

    /**
     * 
     * 
     * @static isObjectValueEqual
     * @param {object} a  
     * @param {object} b 
     * @returns {boolean} is Equal?
     * @memberof Tools
     */
    static isObjectValueEqual(a, b) {
        // Of course, we can do it use for in 
        // Create arrays of property names
        var aProps = Object.getOwnPropertyNames(a);
        var bProps = Object.getOwnPropertyNames(b);

        // If number of properties is different,
        // objects are not equivalent
        if (aProps.length !== bProps.length) {
            return false;
        }

        for (var i = 0; i < aProps.length; i++) {
            var propName = aProps[i];
            // If values of same property are not equal,
            // objects are not equivalent
            if (a[propName] !== b[propName]) {
                return false;
            }
        }

        // If we made it this far, objects
        // are considered equivalent
        return true;
    }
    
    static KVToParamsString(arr){
        return arr.reduce((a, b) => { return a + b.k + '=' + b.v + '&'; }, '?').slice(0, -1);
    }

    /**
     * 转换json格式到Form格式
     * @static
     * @param {object} obj 
     * @returns {formdata} data
     * @memberof Tools
     */
    static json2FormData(obj){
        let data = new FormData();
        for (var props in obj) {
            if (obj.hasOwnProperty(props)) {
                var el = obj[props];
                data.append(props, el);      
            }
        }
        return data;
    }

    static isObject(obj){
        return Object.prototype.toString.call(obj) === '[object Object]';
    }

    /**
     * 递归转换对象为数组
     * @param {object} obj 需要处理的object
     * @param {array} others 需要处理的字段
     */
    static deepObj2array(obj, ...others) {
        obj = Tools.isObject(obj) ? [obj] : obj;
        return obj.map(it => {
            const els = others.filter(_it => it[_it] !== undefined);
            if (els.length > 0) els.forEach(el => it[el] = Tools.deepObj2array(it[el], ...others)) 
            return it;
        })
    }

    /**
     * Transfer json data to post data
     * 
     * @static
     * @param {object} obj post object
     * @param {string} [name='json'] formdata's name, default 'json'
     * @returns {formdata}
     * @memberof Tools
     */
    static json2PostData(obj, name = 'json') {
        return Tools.json2FormData({ [name]: JSON.stringify(obj) });
    }

    static setStorage(key, value){
        localStorage.setItem(key, value);
    }

    static getStorage(key) {
        return localStorage.getItem(key);
    }

    static removeStorage(key) {
        localStorage.removeItem(key);
    }

    static setUser(data) {
        Tools.setStorage('AUTH_ACCESS_LOGIN_TOKEN', data.token);
        delete data.token;
        Tools.setStorage('USER_LOGIN_INFO', data );
    }

    static getUserInfo() {
        return Tools.getStorage('USER_LOGIN_INFO');
    }

    static getUserToken(token) {
        return Tools.getStorage('AUTH_ACCESS_LOGIN_TOKEN');
    }

    static isSignIn(){
        return Tools.getStorage('AUTH_ACCESS_LOGIN_TOKEN') ? true : false;
    }

    static signOut(){
        Tools.removeStorage('AUTH_ACCESS_LOGIN_TOKEN');
        Tools.removeStorage('USER_LOGIN_INFO');
    }

};



module.exports = Tools;