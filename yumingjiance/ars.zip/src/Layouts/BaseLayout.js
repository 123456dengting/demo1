import React, { Component } from 'react';
import { Layout } from 'antd';
import { Route, Switch, Redirect } from 'react-router-dom';
import SiderMenu from "../Components/SiderMenu";
import GlobalHeader from "../Components/GlobalHeader/index";
import * as Utils from '../utils/utils';
import './BaseLayout.css';


class BaseLayout extends Component {
    state = {
        collapsed: false,
    };

    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });  
    }

    signOut = async () => {
        Utils.signOut();
        await Utils.timeout(500);
        this.props.history.push('/user', null);
    }
 
    render() {
        const { collapse } = this.state;
        const { getRouterData, navData, location, openNotification } = this.props;
        return (
            <Layout className="ars-ant-layout">
                <SiderMenu location={location} navData={navData} collapsed={this.state.collapsed} />
                <Layout>
                    <GlobalHeader className="" signOut={this.signOut} toggle={this.toggle} collapse={collapse} />
                    <Switch>
                        {
                            getRouterData('BaseLayout', { openNotification }).map((it, i) => <Route key={`${i}`} path={it.fullPath} component={it.component} {...this.props} /> )
                        }
                        <Redirect from='/' to='ad-monitor/result' />
                    </Switch>
                </Layout>
            </Layout>
        );
    }
}
export default BaseLayout;