import React, { Component } from 'react';
import { Layout } from 'antd';
import { Route, Switch, Redirect } from 'react-router-dom';
import GlobalHeader from "../Components/GlobalHeader/index";
import './UserLayout.css';

class UserLayout extends Component {
    state = {
        collapsed: false,
    };

    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    }
    render() {
        const { collapse } = this.state;
        const { getRouterData } = this.props;
        return (
            <Layout className="ars-ant-layout">
                <Layout>
                    {/* <GlobalHeader className="" toggle={this.toggle} collapse={collapse} /> */}
                    <Switch>
                        {
                            getRouterData('UserLayout').map((it, i) => <Route key={`${i}`} path={it.fullPath} component={it.component} {...this.props} />)
                        }
                        <Redirect from='/user' to='user/login' />
                    </Switch>
                </Layout>
            </Layout>
        );
    }
}
export default UserLayout;