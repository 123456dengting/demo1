import React, { Component } from 'react';
import { Menu, Icon, Layout } from 'antd';
import './index.css';
const { Header } = Layout;
const colorList = ['#f56a00', '#7265e6', '#ffbf00', '#00a2ae'];
class GlobalHeader extends Component {
    
    render() {
        const menu = (
            <Menu>
                <Menu.Item>
                    <a target="_blank" rel="noopener noreferrer" onClick={this.props.signOut}><Icon type="logout" />{`  退出`}</a>
                </Menu.Item>
            </Menu>
        )
        const { collapsed, toggle } = this.props;
        return (
            <Header style={{ background: '#fff', padding: 0 }}>
                <Icon
                    className="trigger"
                    type={collapsed ? 'menu-unfold' : 'menu-fold'}
                    onClick={toggle}
                />
                {/* <div className="login-info">
                    <Dropdown overlay={menu}>
                        <div>
                            <Avatar style={{ backgroundColor: colorList[parseInt(Math.random() * 4)], verticalAlign: 'middle' }} size="large" >{`liyang1`}</Avatar>
                        </div>
                    </Dropdown> 
                </div> */}
            </Header>
        )
    }
}


export default GlobalHeader;