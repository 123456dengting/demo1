import React, { PureComponent } from 'react';
import isEqual from 'lodash.isequal';

export default class ListItems extends PureComponent {
    constructor(props) {
        super(props)
    }
    shouldComponentUpdate = (nextProps, nextState) => {
        return this.props.tmlActiveKey !== nextProps.tmlActiveKey || !isEqual(this.props.data, nextProps.data);
    }
    render() {
        const { props } = this;
        return props.data.map((it, i) => {
            const si = 'i' in props ? props.si + '-' : '';
            return React.cloneElement(props.children, { ...props, it, i, ...{ si: si + i, key: i.toString() } }, '');
        })
    }
}