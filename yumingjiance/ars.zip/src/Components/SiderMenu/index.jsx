import React, { Component } from 'react';
import { Layout, Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';
import './index.css';
const { SubMenu } = Menu;
const { Sider } = Layout;

export default class SiderMenu extends Component {
    constructor(props) {
        super(props);
        const menusData = this.getMenusData(props.navData);
        this.state = {
            collapsed: false,
            openKeys: this.getDefaultOpenKey(menusData),
            selectKeys: this.getDefaultSelectKey(menusData)
        };
    }
    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    }
    getDefaultOpenKey = (menusData) => {
        const { pathname } = this.props.location;
        let pathArr = pathname.split("/");
        pathArr.forEach((it, i) => it.length === 0 ? pathArr.splice(i, 1) : '');
        return pathArr.length >= 2 ? [menusData.findIndex((it, i) => it.path.toLowerCase() === pathArr[0].toLowerCase()).toString()] : ['0'];
    }
    getDefaultSelectKey = (menusData) => {
        const { pathname } = this.props.location;
        const openKeys = this.getDefaultOpenKey(menusData);
        let pathArr = pathname.split("/");
        pathArr.forEach((it, i) => it.length === 0 ? pathArr.splice(i, 1) : '');   
        return pathArr.length >= 2 ? [openKeys[0] + '-' + menusData[openKeys].children.findIndex((it, i) => it.path.toLowerCase() === pathArr[1].toLowerCase()).toString()] : ['0-0'];
    }
    
    getMenusData = navData => navData.find(it => it.layout !== 'UserLayout').children;
    
    handleOpenChange = (openKeys) => {
        this.setState({
            openKeys: [...openKeys],
        });
    }
    render() {
        const { openKeys } = this.state;
        const { collapsed, navData } = this.props;
        const menusData = this.getMenusData(navData);
        const menuProps = collapsed ? {} : {
            openKeys: openKeys,
        };
        return (
            <Sider
                trigger={null}
                collapsible
                collapsed={collapsed}
            >
                <div className="logo">
                    <div className="svg-logo">
                        <svg id="yulansvg" xmlns="http://www.w3.org/2000/svg" data-v-056d9bd8="" version="1.0" width="32.4" height="37.53" viewBox="0 0 100.000000 115.000000" preserveAspectRatio="xMidYMid meet" colorInterpolationFilters="sRGB" className="el-tooltip"><svg width="100" height="100" x="0" y="0"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44.33 44.33"><defs><linearGradient id="ab2a05a2b-d914-4e2d-972d-0b55758a5e91" x1="31.91" y1="23.11" x2="0" y2="23.11" gradientUnits="userSpaceOnUse"><stop offset="0" stopColor="#2dceff"></stop><stop offset="1" stopColor="#ff00d8"></stop></linearGradient><linearGradient id="bba83cd00-3073-4fdb-87aa-55b87de320f5" x1="24.23" y1="28.88" x2="24.23" gradientUnits="userSpaceOnUse"><stop offset="0" stopColor="#ff5652"></stop><stop offset="1" stopColor="#fcb900"></stop></linearGradient><linearGradient id="c43e62bc6-6f1b-4ef9-8cba-27f090f54115" x1="27.71" y1="8.28" x2="27.71" y2="44.33" gradientUnits="userSpaceOnUse"><stop offset="0" stopColor="#0ddb63"></stop><stop offset="1" stopColor="#007ceb"></stop></linearGradient></defs><g><g><path d="M6 21.93A13.87 13.87 0 0 1 11 3a22.17 22.17 0 0 0 .06 38.37 13.88 13.88 0 0 0 14.11-23.93 5.6 5.6 0 0 1-.23 9.56l-.21.11A13.88 13.88 0 0 1 6 21.93z" fill="url(#ab2a05a2b-d914-4e2d-972d-0b55758a5e91)"></path><path d="M30.45 8.28a13.88 13.88 0 0 1 13.88 13.89A22.17 22.17 0 0 0 11 3a13.88 13.88 0 0 0 13.7 24.15 5.6 5.6 0 0 1-8.17-5A13.88 13.88 0 0 1 30.45 8.28z" fill="url(#bba83cd00-3073-4fdb-87aa-55b87de320f5)"></path><path d="M30.45 8.28a13.88 13.88 0 0 0-13.89 13.89A5.6 5.6 0 0 1 25 17.33l.18.11a13.88 13.88 0 0 1-14.09 23.93 22.17 22.17 0 0 0 33.24-19.2A13.88 13.88 0 0 0 30.45 8.28z" fill="url(#c43e62bc6-6f1b-4ef9-8cba-27f090f54115)"></path></g></g></svg></svg><g className="font1 logoname" transform="translate(50, 110)" fill="#ff5652"> <path transform="translate(0, 0)" d=""></path></g><g className="font1 slogan" transform="translate(50, 115)" fill="#007ceb"> <path transform="translate(0, 0)" d=""></path></g></svg>
                    </div>
                    <h1 className="en-text">ARS</h1><h1>自动化测试</h1>
                </div>
                <Menu theme="dark" mode="inline" onOpenChange={this.handleOpenChange} selectedKeys={this.getDefaultSelectKey(menusData)} {...menuProps} >

                    {
                        menusData.map((it, i) => {
                            const itemChildren = it.children.map((_it, j) => <Menu.Item key={`${i}-${j}`}><Link to={`/${it.path}/${_it.path}`}><span>{_it.name}</span></Link></Menu.Item>)
                            return (
                                <SubMenu key={`${i}`} title={<span><Icon type={it.icon} /><span>{it.name}</span></span>}>
                                    {itemChildren}
                                </SubMenu>
                            )
                        })
                    }
                </Menu>
            </Sider>
        );
    }
}
