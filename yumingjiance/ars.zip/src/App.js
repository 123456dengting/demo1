import React from 'react';
import BaseLayout from './Layouts/BaseLayout';
import UserLayout from './Layouts/UserLayout';
import { menusData } from "./common/nav";
import { Route, Switch, Redirect } from 'react-router';
import { notification, Icon } from 'antd'
import './App.css';
function App(props) {
    const getMenusData = (data, moduleName) => data.find(it => it.layout === moduleName).children.reduce((a, b) =>
        a.concat(b.children.map(it => { it.fullPath = `/${b.path}/${it.path}`; return it; })), []);

    const openNotification = (content, title = 'Notification') => {
        notification.open({
            message: title,
            description: content,
            icon: <Icon type="smile-circle" style={{ color: '#108ee9' }} />,
        });
    };

    const passProps = {
        navData: menusData({}),
        getRouterData: (moduleName, passProps) => {
            return getMenusData(menusData(passProps), moduleName)
        },
        openNotification
    }

    // const isSignIn = Utils.isSignIn();
    const isSignIn = true;

    return (
        <Switch>
            <Route path="/user" render={() => isSignIn ? <Redirect to="/" /> : <UserLayout {...props} {...passProps} /> } />
            <Route path="/" render={() => isSignIn ? <BaseLayout {...props} {...passProps} /> : <Redirect to="/user/login" /> } />
        </Switch>
    )
    
}  

export default App;