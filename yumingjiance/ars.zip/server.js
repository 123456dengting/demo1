var express = require('express');
var path = require('path');
var app = express();
var c = require('child_process');
app.use(express.static(path.join(__dirname, 'build')));

app.get('*', (req, res) =>{
    res.sendFile(path.join(__dirname, 'build/index.html'))
})

var server = app.listen('3008', function () {
    console.info('Express server listening on port ' + server.address().port);
})

// c.exec('start http://127.0.0.1:3008');